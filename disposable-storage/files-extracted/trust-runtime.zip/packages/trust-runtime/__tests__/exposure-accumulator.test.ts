import { describe, it, expect } from 'vitest';
import {
  ExposureAccumulator,
  classifyRiskTier,
  DEFAULT_TIER_WEIGHTS,
  TieredTransaction,
} from '../exposure-accumulator';

const thresholds = { highValue: 100, highVolatility: 0.8, medValue: 20, medVolatility: 0.4 };

function tx(value: number, volatilityScore = 0.1, eventTimestamp = 0, arrivalTimestamp = 0): TieredTransaction {
  return { value, volatilityScore, eventTimestamp, arrivalTimestamp };
}

describe('exposure-accumulator', () => {
  it('classifies by value threshold', () => {
    expect(classifyRiskTier(150, 0.1, thresholds)).toBe('HIGH');
    expect(classifyRiskTier(50, 0.1, thresholds)).toBe('MEDIUM');
    expect(classifyRiskTier(5, 0.1, thresholds)).toBe('LOW');
  });

  it('classifies by volatility threshold even if value is low', () => {
    expect(classifyRiskTier(1, 0.9, thresholds)).toBe('HIGH');
    expect(classifyRiskTier(1, 0.5, thresholds)).toBe('MEDIUM');
  });

  it('accumulates value into the correct bucket', () => {
    const acc = new ExposureAccumulator();
    acc.record(tx(100), 'HIGH');
    acc.record(tx(50), 'MEDIUM');
    acc.record(tx(10), 'LOW');
    const buckets = acc.getBuckets();
    expect(buckets.HIGH).toBe(100);
    expect(buckets.MEDIUM).toBe(50);
    expect(buckets.LOW).toBe(10);
  });

  it('computes tier-weighted total risk', () => {
    const acc = new ExposureAccumulator(DEFAULT_TIER_WEIGHTS);
    acc.record(tx(100), 'HIGH'); // *5.0
    acc.record(tx(100), 'LOW'); // *1.0
    expect(acc.totalIntegratedRisk()).toBeCloseTo(100 * 5.0 + 100 * 1.0);
  });

  it('event-time-based accumulation is unaffected by out-of-order arrival', () => {
    const acc = new ExposureAccumulator();
    // Transaction with an old event time arrives late (network delay simulation).
    acc.record(tx(100, 0.1, /*event*/ 1000, /*arrival*/ 9000), 'LOW');
    acc.record(tx(50, 0.1, /*event*/ 2000, /*arrival*/ 2100), 'LOW');
    // Regardless of arrival order, both values land in the same bucket by tier —
    // accumulation is not time-sliced, so out-of-order arrival cannot corrupt it.
    expect(acc.getBuckets().LOW).toBe(150);
  });

  it('tracks the high-water mark of arrival timestamps', () => {
    const acc = new ExposureAccumulator();
    acc.record(tx(1, 0.1, 1000, 5000), 'LOW');
    acc.record(tx(1, 0.1, 1000, 3000), 'LOW');
    expect(acc.getWatermark()).toBe(5000);
  });

  it('normalizes exposure to [0,1] against the ceiling', () => {
    const acc = new ExposureAccumulator();
    acc.record(tx(50), 'LOW'); // weight 1.0 -> total 50
    expect(acc.normalizedExposure(100)).toBeCloseTo(0.5);
    expect(acc.normalizedExposure(10)).toBe(1); // clamped
  });

  it('reset clears all buckets', () => {
    const acc = new ExposureAccumulator();
    acc.record(tx(50), 'HIGH');
    acc.reset();
    expect(acc.totalIntegratedRisk()).toBe(0);
  });
});
