import { describe, it, expect } from 'vitest';
import { DistributedKillSwitch, KillSwitchStore } from '../distributed-kill-switch';

function makeMockStore(initial = false): KillSwitchStore & { getCallCount: number } {
  let state = initial;
  const store = {
    getCallCount: 0,
    async get() {
      store.getCallCount++;
      return state;
    },
    async set(engaged: boolean) {
      state = engaged;
    },
  };
  return store;
}

describe('DistributedKillSwitch', () => {
  it('reads from the store, not local memory, on first check', async () => {
    const store = makeMockStore(true);
    const killSwitch = new DistributedKillSwitch(store, { pollIntervalMs: 1000 });
    expect(await killSwitch.isEngaged(0)).toBe(true);
    expect(store.getCallCount).toBe(1);
  });

  it('caches within pollIntervalMs rather than hitting the store on every check', async () => {
    const store = makeMockStore(false);
    const killSwitch = new DistributedKillSwitch(store, { pollIntervalMs: 1000 });
    await killSwitch.isEngaged(0);
    await killSwitch.isEngaged(500); // within poll interval
    expect(store.getCallCount).toBe(1);
  });

  it('re-polls after pollIntervalMs elapses', async () => {
    const store = makeMockStore(false);
    const killSwitch = new DistributedKillSwitch(store, { pollIntervalMs: 1000 });
    await killSwitch.isEngaged(0);
    await killSwitch.isEngaged(1500); // past poll interval
    expect(store.getCallCount).toBe(2);
  });

  it('isEngagedUncached always hits the store, bypassing the cache window', async () => {
    const store = makeMockStore(false);
    const killSwitch = new DistributedKillSwitch(store, { pollIntervalMs: 100_000 });
    await killSwitch.isEngaged(0);
    await killSwitch.isEngagedUncached();
    await killSwitch.isEngagedUncached();
    expect(store.getCallCount).toBe(3);
  });

  it('engage() writes through to the store and updates the local cache immediately', async () => {
    const store = makeMockStore(false);
    const killSwitch = new DistributedKillSwitch(store, { pollIntervalMs: 100_000 });
    await killSwitch.engage('ops-team', 'suspected exploit');
    expect(await killSwitch.isEngaged(0)).toBe(true);
    // isEngaged should use the freshly-updated cache, not force another store hit
    expect(store.getCallCount).toBe(0);
  });

  it('disengage() writes through and clears the cached value', async () => {
    const store = makeMockStore(true);
    const killSwitch = new DistributedKillSwitch(store, { pollIntervalMs: 100_000 });
    await killSwitch.disengage('ops-team', 'resolved');
    expect(await killSwitch.isEngaged(0)).toBe(false);
  });
});
