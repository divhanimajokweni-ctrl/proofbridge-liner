import { describe, it, expect } from 'vitest';
import { runGatePipeline, AIRHaltedError } from '../gate-pipeline';
import { createCircuitBreakerState } from '../circuit-breaker';
import { DEFAULT_AIR_CONFIG, Intent, AIRConfig } from '../types';
import { ExposureSample } from '../velocity-monitor';

function baseInput(now: number) {
  const intent: Intent = {
    id: 'i1',
    createdAt: now - 1000,
    snapshotState: { liquidity: 100 },
    baseWeight: 1,
  };
  const exposureHistory: ExposureSample[] = [
    { timestamp: now - 1000, exposure: 10 },
    { timestamp: now, exposure: 12 },
  ];
  return {
    intent,
    currentState: { liquidity: 100 },
    exposureHistory,
    entropy: 0.1,
    failures: 0.1,
    convergencePenalty: 0,
    previousSmoothedScore: 0.1,
    previousBreakerState: createCircuitBreakerState(now - 1000),
    now,
  };
}

describe('gate-pipeline (observe mode)', () => {
  it('never throws in observe mode even when thresholds are exceeded', () => {
    const now = 1_000_000;
    const config: AIRConfig = { ...DEFAULT_AIR_CONFIG, enforceAt: 'observe', exposureCeiling: 1 };
    const input = { ...baseInput(now), currentState: { liquidity: 99999 } }; // huge drift
    expect(() => runGatePipeline(input, config)).not.toThrow();
    const result = runGatePipeline(input, config);
    expect(result.halted).toBe(false);
  });

  it('computes a full metrics object with all fields in [0,1]', () => {
    const now = 1_000_000;
    const config: AIRConfig = { ...DEFAULT_AIR_CONFIG, enforceAt: 'observe' };
    const result = runGatePipeline(baseInput(now), config);
    for (const value of Object.values(result.metrics)) {
      expect(value).toBeGreaterThanOrEqual(0);
      expect(value).toBeLessThanOrEqual(1);
    }
  });
});

describe('gate-pipeline (enforce mode)', () => {
  it('throws AIRHaltedError when state drift exceeds maxDrift', () => {
    const now = 1_000_000;
    const config: AIRConfig = { ...DEFAULT_AIR_CONFIG, enforceAt: 'enforce', maxDrift: 1 };
    const input = { ...baseInput(now), currentState: { liquidity: 99999 } };
    expect(() => runGatePipeline(input, config)).toThrow(AIRHaltedError);
  });

  it('throws AIRHaltedError when the intent has expired', () => {
    const now = 1_000_000;
    const config: AIRConfig = { ...DEFAULT_AIR_CONFIG, enforceAt: 'enforce', maxIntentAgeMs: 500 };
    const input = baseInput(now); // intent created 1000ms before now, maxAge=500ms
    expect(() => runGatePipeline(input, config)).toThrow();
  });

  it('does not throw for a well-behaved, low-drift, fresh intent', () => {
    const now = 1_000_000;
    const config: AIRConfig = {
      ...DEFAULT_AIR_CONFIG,
      enforceAt: 'enforce',
      maxDrift: 100,
      maxVelocity: 100,
      maxAcceleration: 100,
      exposureCeiling: 1000,
    };
    const input = baseInput(now);
    expect(() => runGatePipeline(input, config)).not.toThrow();
  });
});
