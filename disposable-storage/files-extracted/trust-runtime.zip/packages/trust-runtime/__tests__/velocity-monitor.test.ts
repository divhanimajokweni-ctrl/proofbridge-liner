import { describe, it, expect } from 'vitest';
import {
  computeMultiWindowVelocity,
  checkVelocityGate,
  checkAccelerationGate,
  smoothVelocity,
  normalizeAgainstThreshold,
  ExposureSample,
} from '../velocity-monitor';

describe('velocity-monitor', () => {
  it('returns empty when there is no current sample', () => {
    const result = computeMultiWindowVelocity([], 1000);
    expect(result).toEqual({});
  });

  it('computes 5m velocity from two samples 5 minutes apart', () => {
    const samples: ExposureSample[] = [
      { timestamp: 0, exposure: 0 },
      { timestamp: 5 * 60 * 1000, exposure: 300 },
    ];
    const result = computeMultiWindowVelocity(samples, 5 * 60 * 1000);
    // 300 units over 300 seconds = 1 unit/sec
    expect(result['5m']).toBeCloseTo(1, 5);
  });

  it('omits a window when there is no baseline sample old enough', () => {
    const samples: ExposureSample[] = [{ timestamp: 0, exposure: 0 }];
    const result = computeMultiWindowVelocity(samples, 1000); // far short of any window
    expect(result['5m']).toBeUndefined();
    expect(result['72h']).toBeUndefined();
  });

  it('detects a catastrophic 5-minute drain invisible to a 72h average', () => {
    const now = 72 * 60 * 60 * 1000;
    const samples: ExposureSample[] = [
      { timestamp: 0, exposure: 1000 }, // 72h ago, high exposure
      { timestamp: now - 5 * 60 * 1000, exposure: 1000 }, // flat for 72h...
      { timestamp: now, exposure: 0 }, // ...then drained in the last 5 minutes
    ];
    const velocities = computeMultiWindowVelocity(samples, now);
    // 72h macro trend looks roughly flat (small negative slope over the full window)
    expect(Math.abs(velocities['72h']!)).toBeLessThan(1);
    // but the local 5m velocity is a massive drain
    expect(velocities['5m']).toBeLessThan(-3);
  });

  it('velocity gate trips when local velocity exceeds maxVelocity', () => {
    const result = checkVelocityGate({ '5m': -5 }, 3);
    expect(result.tripped).toBe(true);
  });

  it('velocity gate does not trip below threshold', () => {
    const result = checkVelocityGate({ '5m': 1 }, 3);
    expect(result.tripped).toBe(false);
  });

  it('velocity gate does not trip (rather than false-trip) when there is no 5m sample yet', () => {
    const result = checkVelocityGate({}, 3);
    expect(result.tripped).toBe(false);
    expect(result.localVelocity).toBeNull();
  });

  it('acceleration gate trips when local deviates sharply from macro', () => {
    const result = checkAccelerationGate({ '5m': -5, '72h': 0.01 }, 1);
    expect(result.tripped).toBe(true);
  });

  it('acceleration gate does not trip when local and macro track closely', () => {
    const result = checkAccelerationGate({ '5m': 0.5, '72h': 0.4 }, 1);
    expect(result.tripped).toBe(false);
  });

  it('smoothVelocity applies EWMA damping toward recent values', () => {
    const smoothed = smoothVelocity([1, 1, 1, 10], 0.5);
    expect(smoothed).toBeGreaterThan(1);
    expect(smoothed).toBeLessThan(10);
  });

  it('normalizeAgainstThreshold clamps to [0,1]', () => {
    expect(normalizeAgainstThreshold(5, 10)).toBeCloseTo(0.5);
    expect(normalizeAgainstThreshold(-15, 10)).toBe(1);
    expect(normalizeAgainstThreshold(5, 0)).toBe(0);
  });
});
