import { describe, it, expect } from 'vitest';
import { createDecayingCounter, recordEvent, decayCounter, readDecayedValue, normalizeCounter } from '../decay-counter';

const HALF_LIFE_MS = 5 * 60 * 1000;

describe('decay-counter', () => {
  it('decays a counter to ~half after one half-life elapses', () => {
    const now0 = 1_000_000;
    const counter = createDecayingCounter(10, now0);
    decayCounter(counter, now0 + HALF_LIFE_MS, HALF_LIFE_MS);
    expect(counter.value).toBeCloseTo(5, 1);
  });

  it('decays to ~quarter after two half-lives', () => {
    const now0 = 0;
    const counter = createDecayingCounter(10, now0);
    decayCounter(counter, now0 + 2 * HALF_LIFE_MS, HALF_LIFE_MS);
    expect(counter.value).toBeCloseTo(2.5, 1);
  });

  it('recordEvent decays prior state before adding the new event', () => {
    const now0 = 0;
    const counter = createDecayingCounter(10, now0);
    recordEvent(counter, HALF_LIFE_MS, 1, now0 + HALF_LIFE_MS);
    // 10 decayed to 5, plus 1 new event = 6
    expect(counter.value).toBeCloseTo(6, 1);
  });

  it('readDecayedValue does not mutate the counter', () => {
    const now0 = 0;
    const counter = createDecayingCounter(10, now0);
    const value = readDecayedValue(counter, HALF_LIFE_MS, now0 + HALF_LIFE_MS);
    expect(value).toBeCloseTo(5, 1);
    expect(counter.value).toBe(10); // unchanged
    expect(counter.lastUpdated).toBe(0); // unchanged
  });

  it('never goes negative or increases from decay alone', () => {
    const now0 = 0;
    const counter = createDecayingCounter(10, now0);
    decayCounter(counter, now0 + 100 * HALF_LIFE_MS, HALF_LIFE_MS);
    expect(counter.value).toBeGreaterThanOrEqual(0);
    expect(counter.value).toBeLessThan(0.001);
  });

  it('normalizeCounter clamps to [0,1]', () => {
    expect(normalizeCounter(5, 10)).toBeCloseTo(0.5);
    expect(normalizeCounter(20, 10)).toBe(1);
    expect(normalizeCounter(-5, 10)).toBe(0);
    expect(normalizeCounter(5, 0)).toBe(0);
  });
});
