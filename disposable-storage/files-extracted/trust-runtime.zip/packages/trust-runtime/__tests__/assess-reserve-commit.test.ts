import { describe, it, expect } from 'vitest';
import { InMemoryReservationStore, withReservation, AIRCapacityRejectedError } from '../assess-reserve-commit';

describe('InMemoryReservationStore', () => {
  it('reserves capacity up to the ceiling', async () => {
    const store = new InMemoryReservationStore();
    const id = await store.reserve('key1', 50, 100);
    expect(id).not.toBeNull();
    expect(await store.currentTotal('key1')).toBe(50);
  });

  it('rejects a reservation that would exceed the ceiling', async () => {
    const store = new InMemoryReservationStore();
    await store.reserve('key1', 80, 100);
    const second = await store.reserve('key1', 30, 100); // 80+30=110 > 100
    expect(second).toBeNull();
    expect(await store.currentTotal('key1')).toBe(80); // unchanged by the rejected attempt
  });

  it('release frees the reserved capacity', async () => {
    const store = new InMemoryReservationStore();
    const id = await store.reserve('key1', 50, 100);
    await store.release(id!);
    expect(await store.currentTotal('key1')).toBe(0);
    // capacity is available again
    const second = await store.reserve('key1', 100, 100);
    expect(second).not.toBeNull();
  });

  it('commit finalizes a reservation and prevents subsequent release', async () => {
    const store = new InMemoryReservationStore();
    const id = await store.reserve('key1', 50, 100);
    await store.commit(id!);
    await expect(store.release(id!)).rejects.toThrow();
  });

  it(
    'THE P0 REGRESSION TEST: two concurrent reservations against the same ceiling ' +
      'cannot both succeed if their combined amount exceeds it — this is the exact ' +
      'race the audit flagged in "record, then assess"',
    async () => {
      const store = new InMemoryReservationStore();
      const ceiling = 100;

      // Simulate two "concurrent" requests each trying to reserve 60 against a
      // ceiling of 100. Under check-then-record, both could read the same
      // pre-update total and both pass. Under reserve-then-commit, only one can.
      const [first, second] = await Promise.all([
        store.reserve('shared-key', 60, ceiling),
        store.reserve('shared-key', 60, ceiling),
      ]);

      const succeeded = [first, second].filter((x) => x !== null);
      expect(succeeded.length).toBe(1); // exactly one must succeed
      expect(await store.currentTotal('shared-key')).toBeLessThanOrEqual(ceiling);
    }
  );
});

describe('withReservation', () => {
  it('commits automatically when the operation succeeds', async () => {
    const store = new InMemoryReservationStore();
    const result = await withReservation(store, 'k', 10, 100, async () => 'done');
    expect(result).toBe('done');
    expect(await store.currentTotal('k')).toBe(10);
  });

  it('releases the reservation automatically when the operation throws', async () => {
    const store = new InMemoryReservationStore();
    await expect(
      withReservation(store, 'k', 10, 100, async () => {
        throw new Error('downstream failure');
      })
    ).rejects.toThrow('downstream failure');
    // Capacity must be freed, not leaked, on failure.
    expect(await store.currentTotal('k')).toBe(0);
  });

  it('throws AIRCapacityRejectedError before ever calling the operation, when over ceiling', async () => {
    const store = new InMemoryReservationStore();
    await store.reserve('k', 90, 100);
    let operationCalled = false;
    await expect(
      withReservation(store, 'k', 20, 100, async () => {
        operationCalled = true;
        return 'should not run';
      })
    ).rejects.toThrow(AIRCapacityRejectedError);
    expect(operationCalled).toBe(false);
  });
});
