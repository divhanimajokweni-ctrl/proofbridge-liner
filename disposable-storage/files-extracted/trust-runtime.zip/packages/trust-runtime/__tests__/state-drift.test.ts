import { describe, it, expect } from 'vitest';
import { computeStateDistance, normalizedDrift, checkDriftGate } from '../state-drift';

describe('state-drift', () => {
  it('returns 0 distance for identical vectors', () => {
    const v = { liquidity: 100, exposure: 50 };
    expect(computeStateDistance(v, v)).toBe(0);
  });

  it('computes Euclidean distance for differing vectors', () => {
    const a = { x: 0, y: 0 };
    const b = { x: 3, y: 4 };
    expect(computeStateDistance(a, b)).toBeCloseTo(5); // 3-4-5 triangle
  });

  it('treats a field present only in one vector as drift from 0', () => {
    const a = { x: 3 };
    const b = { x: 3, y: 4 };
    expect(computeStateDistance(a, b)).toBeCloseTo(4);
  });

  it('normalizes drift to [0,1] against maxDrift', () => {
    const a = { x: 0 };
    const b = { x: 5 };
    expect(normalizedDrift(a, b, 10)).toBeCloseTo(0.5);
    expect(normalizedDrift(a, b, 2)).toBe(1); // clamped
  });

  it('drift gate trips when distance exceeds maxDrift', () => {
    const a = { x: 0 };
    const b = { x: 100 };
    const result = checkDriftGate(a, b, 10);
    expect(result.tripped).toBe(true);
    expect(result.distance).toBeCloseTo(100);
    expect(result.normalized).toBe(1);
  });

  it('drift gate does not trip within bounds', () => {
    const a = { x: 0 };
    const b = { x: 1 };
    const result = checkDriftGate(a, b, 10);
    expect(result.tripped).toBe(false);
  });
});
