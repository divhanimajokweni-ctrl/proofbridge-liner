import { describe, it, expect } from 'vitest';
import {
  computeRiskScore,
  computeDeltaScore,
  computeSmoothedScore,
  AIRUnnormalizedMetricError,
  DEFAULT_RISK_WEIGHTS,
} from '../risk-score-engine';
import { GateMetrics } from '../types';

const baseMetrics: GateMetrics = {
  exposure: 0.5,
  failures: 0.1,
  entropy: 0.1,
  velocity: 0.1,
  acceleration: 0,
  intentAge: 0.2,
  drift: 0.1,
  convergencePenalty: 0,
};

describe('risk-score-engine', () => {
  it('computes a bounded score for mid-range normalized inputs', () => {
    const score = computeRiskScore(baseMetrics);
    expect(score).toBeGreaterThan(0);
    expect(score).toBeLessThan(1);
  });

  it('returns 0 for all-zero metrics', () => {
    const zero: GateMetrics = {
      exposure: 0,
      failures: 0,
      entropy: 0,
      velocity: 0,
      acceleration: 0,
      intentAge: 0,
      drift: 0,
      convergencePenalty: 0,
    };
    expect(computeRiskScore(zero)).toBe(0);
  });

  it('is monotonically non-decreasing in exposure holding other inputs fixed', () => {
    const low = computeRiskScore({ ...baseMetrics, exposure: 0.2 });
    const high = computeRiskScore({ ...baseMetrics, exposure: 0.8 });
    expect(high).toBeGreaterThan(low);
  });

  it('rejects unnormalized inputs above 1 rather than silently producing an unbounded score', () => {
    const bad: GateMetrics = { ...baseMetrics, intentAge: 1.5 };
    expect(() => computeRiskScore(bad)).toThrow(AIRUnnormalizedMetricError);
  });

  it('rejects negative inputs', () => {
    const bad: GateMetrics = { ...baseMetrics, drift: -0.1 };
    expect(() => computeRiskScore(bad)).toThrow(AIRUnnormalizedMetricError);
  });

  it('rejects NaN inputs', () => {
    const bad: GateMetrics = { ...baseMetrics, velocity: NaN };
    expect(() => computeRiskScore(bad)).toThrow(AIRUnnormalizedMetricError);
  });

  it('normalized intentAge^2 stays bounded even at max age (regression test for the P0 fix)', () => {
    // Original proposal squared a possibly-unnormalized intentAge directly.
    // With intentAge correctly normalized to [0,1], intentAge=1 contributes at
    // most weights.intentAgeSquared to the score, never an unbounded term.
    const atExpiry: GateMetrics = { ...baseMetrics, intentAge: 1, drift: 1 };
    const score = computeRiskScore(atExpiry);
    const maxPossibleContribution =
      DEFAULT_RISK_WEIGHTS.intentAgeSquared + DEFAULT_RISK_WEIGHTS.driftIntentAgeCross;
    expect(score).toBeLessThan(
      DEFAULT_RISK_WEIGHTS.exposure +
        DEFAULT_RISK_WEIGHTS.failures +
        DEFAULT_RISK_WEIGHTS.entropy +
        DEFAULT_RISK_WEIGHTS.velocity +
        DEFAULT_RISK_WEIGHTS.acceleration +
        DEFAULT_RISK_WEIGHTS.drift +
        DEFAULT_RISK_WEIGHTS.convergencePenalty +
        maxPossibleContribution +
        0.001
    );
  });

  it('detects rising instability via delta score', () => {
    expect(computeDeltaScore(0.7, 0.4)).toBeCloseTo(0.3);
  });

  it('detects falling risk via negative delta score', () => {
    expect(computeDeltaScore(0.2, 0.5)).toBeCloseTo(-0.3);
  });

  it('smoothed score moves toward the current score at rate alpha', () => {
    const smoothed = computeSmoothedScore(1.0, 0.0, 0.2);
    expect(smoothed).toBeCloseTo(0.2);
  });

  it('smoothed score with alpha=1 equals the raw current score', () => {
    expect(computeSmoothedScore(0.6, 0.1, 1.0)).toBeCloseTo(0.6);
  });

  it('smoothed score with alpha=0 equals the previous smoothed score', () => {
    expect(computeSmoothedScore(0.6, 0.1, 0.0)).toBeCloseTo(0.1);
  });
});
