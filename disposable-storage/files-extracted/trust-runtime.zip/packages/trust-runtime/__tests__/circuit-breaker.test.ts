import { describe, it, expect } from 'vitest';
import { createCircuitBreakerState, evaluateCircuitBreaker, DEFAULT_ESCALATION_POLICY } from '../circuit-breaker';
import { DEFAULT_AIR_CONFIG } from '../types';

describe('circuit-breaker', () => {
  it('stays NORMAL for low score and low delta', () => {
    const state = createCircuitBreakerState(0);
    const next = evaluateCircuitBreaker(state, { score: 0.1, deltaScore: 0.01, now: 1000 }, DEFAULT_AIR_CONFIG);
    expect(next.current).toBe('NORMAL');
  });

  it('transitions to WARNING at the warning threshold', () => {
    const state = createCircuitBreakerState(0);
    const next = evaluateCircuitBreaker(
      state,
      { score: DEFAULT_AIR_CONFIG.riskScoreThresholds.warning, deltaScore: 0, now: 1000 },
      DEFAULT_AIR_CONFIG
    );
    expect(next.current).toBe('WARNING');
  });

  it('transitions to TRIPPED at the tripped threshold', () => {
    const state = createCircuitBreakerState(0);
    const next = evaluateCircuitBreaker(
      state,
      { score: DEFAULT_AIR_CONFIG.riskScoreThresholds.tripped, deltaScore: 0, now: 1000 },
      DEFAULT_AIR_CONFIG
    );
    expect(next.current).toBe('TRIPPED');
  });

  it('does not go directly from TRIPPED to NORMAL — enforces a RECOVERY hold', () => {
    let state = createCircuitBreakerState(0);
    state = evaluateCircuitBreaker(state, { score: 0.8, deltaScore: 0, now: 1000 }, DEFAULT_AIR_CONFIG);
    expect(state.current).toBe('TRIPPED');

    // Score drops back to normal immediately after.
    state = evaluateCircuitBreaker(state, { score: 0.1, deltaScore: -0.7, now: 1100 }, DEFAULT_AIR_CONFIG);
    expect(state.current).toBe('RECOVERY');
  });

  it('holds RECOVERY until minRecoveryHoldMs elapses, then returns to NORMAL', () => {
    let state = createCircuitBreakerState(0);
    state = evaluateCircuitBreaker(state, { score: 0.8, deltaScore: 0, now: 1000 }, DEFAULT_AIR_CONFIG);
    state = evaluateCircuitBreaker(state, { score: 0.1, deltaScore: -0.7, now: 1100 }, DEFAULT_AIR_CONFIG);
    expect(state.current).toBe('RECOVERY');

    // Not enough time has passed.
    state = evaluateCircuitBreaker(
      state,
      { score: 0.1, deltaScore: 0, now: 1100 + DEFAULT_ESCALATION_POLICY.minRecoveryHoldMs - 1 },
      DEFAULT_AIR_CONFIG
    );
    expect(state.current).toBe('RECOVERY');

    // Hold duration satisfied.
    state = evaluateCircuitBreaker(
      state,
      { score: 0.1, deltaScore: 0, now: 1100 + DEFAULT_ESCALATION_POLICY.minRecoveryHoldMs + 1 },
      DEFAULT_AIR_CONFIG
    );
    expect(state.current).toBe('NORMAL');
  });

  it('re-trips immediately if instability recurs during RECOVERY', () => {
    let state = createCircuitBreakerState(0);
    state = evaluateCircuitBreaker(state, { score: 0.8, deltaScore: 0, now: 1000 }, DEFAULT_AIR_CONFIG);
    state = evaluateCircuitBreaker(state, { score: 0.1, deltaScore: -0.7, now: 1100 }, DEFAULT_AIR_CONFIG);
    expect(state.current).toBe('RECOVERY');

    // score 0.85 is >= tripped(0.75) and < escalated(0.9); deltaScore 0.15 is
    // >= tripped(0.1) and < escalated(0.2) — this must land on TRIPPED, not
    // jump straight past it to ESCALATED.
    state = evaluateCircuitBreaker(state, { score: 0.85, deltaScore: 0.15, now: 1200 }, DEFAULT_AIR_CONFIG);
    expect(state.current).toBe('TRIPPED');
  });

  it('escalates after repeated trips within the escalation window', () => {
    let state = createCircuitBreakerState(0);
    const policy = { ...DEFAULT_ESCALATION_POLICY, tripsToEscalate: 2 };

    state = evaluateCircuitBreaker(state, { score: 0.8, deltaScore: 0, now: 1000 }, DEFAULT_AIR_CONFIG, policy);
    expect(state.current).toBe('TRIPPED');
    expect(state.tripCountInWindow).toBe(1);

    state = evaluateCircuitBreaker(state, { score: 0.1, deltaScore: -0.7, now: 1100 }, DEFAULT_AIR_CONFIG, policy);
    expect(state.current).toBe('RECOVERY');

    // score 0.8 and deltaScore 0.15 land on TRIPPED on their own merits (not a
    // direct ESCALATED threshold breach), so this exercises the trip-count
    // escalation path: this is the 2nd TRIPPED entry within the window, and
    // policy.tripsToEscalate is 2, so it must be force-escalated.
    state = evaluateCircuitBreaker(state, { score: 0.8, deltaScore: 0.15, now: 1200 }, DEFAULT_AIR_CONFIG, policy);
    expect(state.current).toBe('ESCALATED');
    expect(state.tripCountInWindow).toBe(2);
  });

  it('escalates immediately at the escalated score threshold regardless of trip count', () => {
    const state = createCircuitBreakerState(0);
    const next = evaluateCircuitBreaker(
      state,
      { score: DEFAULT_AIR_CONFIG.riskScoreThresholds.escalated, deltaScore: 0, now: 1000 },
      DEFAULT_AIR_CONFIG
    );
    expect(next.current).toBe('ESCALATED');
  });

  it('trips on a sharp delta even if absolute score is still low', () => {
    const state = createCircuitBreakerState(0);
    const next = evaluateCircuitBreaker(
      state,
      { score: 0.3, deltaScore: DEFAULT_AIR_CONFIG.deltaScoreThresholds.tripped, now: 1000 },
      DEFAULT_AIR_CONFIG
    );
    expect(next.current).toBe('TRIPPED');
  });
});
