import { describe, it, expect } from 'vitest';
import { evaluateIntentWeight, assertIntentNotExpired, AIRIntentExpiredError } from '../intent-aging';
import { Intent } from '../types';

const MAX_AGE_MS = 72 * 60 * 60 * 1000;

function makeIntent(createdAt: number, baseWeight = 1): Intent {
  return { id: 'intent_1', createdAt, snapshotState: {}, baseWeight };
}

describe('intent-aging', () => {
  it('has full weight and zero normalized age at creation', () => {
    const intent = makeIntent(0, 1);
    const result = evaluateIntentWeight(intent, 0, MAX_AGE_MS);
    expect(result.weight).toBeCloseTo(1, 2);
    expect(result.normalizedAge).toBe(0);
    expect(result.expired).toBe(false);
  });

  it('decays weight monotonically as time passes', () => {
    const intent = makeIntent(0, 1);
    const early = evaluateIntentWeight(intent, 1 * 60 * 60 * 1000, MAX_AGE_MS);
    const late = evaluateIntentWeight(intent, 60 * 60 * 60 * 1000, MAX_AGE_MS);
    expect(late.weight).toBeLessThan(early.weight);
  });

  it('normalizedAge increases linearly with elapsed time relative to maxIntentAgeMs', () => {
    const intent = makeIntent(0, 1);
    const result = evaluateIntentWeight(intent, MAX_AGE_MS / 2, MAX_AGE_MS);
    expect(result.normalizedAge).toBeCloseTo(0.5);
  });

  it('marks expired exactly at maxIntentAgeMs', () => {
    const intent = makeIntent(0, 1);
    const result = evaluateIntentWeight(intent, MAX_AGE_MS, MAX_AGE_MS);
    expect(result.expired).toBe(true);
    expect(result.weight).toBe(0);
    expect(result.normalizedAge).toBe(1);
  });

  it('weight approaches floorAtExpiry just before hard expiry', () => {
    const intent = makeIntent(0, 1);
    const floor = 0.01;
    const result = evaluateIntentWeight(intent, MAX_AGE_MS - 1, MAX_AGE_MS, floor);
    expect(result.weight).toBeCloseTo(floor, 1);
  });

  it('assertIntentNotExpired throws AIRIntentExpiredError past the limit', () => {
    const intent = makeIntent(0, 1);
    expect(() => assertIntentNotExpired(intent, MAX_AGE_MS + 1, MAX_AGE_MS)).toThrow(AIRIntentExpiredError);
  });

  it('assertIntentNotExpired does not throw before the limit', () => {
    const intent = makeIntent(0, 1);
    expect(() => assertIntentNotExpired(intent, MAX_AGE_MS - 1, MAX_AGE_MS)).not.toThrow();
  });

  it('baseWeight scales the decayed weight proportionally', () => {
    const intent = makeIntent(0, 2);
    const result = evaluateIntentWeight(intent, 0, MAX_AGE_MS);
    expect(result.weight).toBeCloseTo(2, 2);
  });
});
