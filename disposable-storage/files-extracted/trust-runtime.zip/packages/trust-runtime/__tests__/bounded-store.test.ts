import { describe, it, expect } from 'vitest';
import { BoundedRingBuffer, BoundedLRUMap } from '../bounded-store';

describe('BoundedRingBuffer', () => {
  it('never exceeds its configured capacity', () => {
    const buf = new BoundedRingBuffer<number>({ capacity: 3 });
    for (let i = 0; i < 10; i++) buf.push(i);
    expect(buf.length).toBe(3);
  });

  it('evicts oldest-first (FIFO)', () => {
    const buf = new BoundedRingBuffer<number>({ capacity: 3 });
    [1, 2, 3, 4].forEach((n) => buf.push(n));
    expect(buf.toArray()).toEqual([2, 3, 4]);
  });

  it('calls onEvict with the evicted item, not the retained ones', () => {
    const evicted: number[] = [];
    const buf = new BoundedRingBuffer<number>({ capacity: 2, onEvict: (x) => evicted.push(x) });
    [1, 2, 3, 4].forEach((n) => buf.push(n));
    expect(evicted).toEqual([1, 2]);
  });

  it('recent(n) returns the last n items in order', () => {
    const buf = new BoundedRingBuffer<number>({ capacity: 5 });
    [1, 2, 3, 4, 5].forEach((n) => buf.push(n));
    expect(buf.recent(2)).toEqual([4, 5]);
  });

  it('throws on non-positive capacity', () => {
    expect(() => new BoundedRingBuffer({ capacity: 0 })).toThrow();
  });
});

describe('BoundedLRUMap', () => {
  it('never exceeds capacity', () => {
    const map = new BoundedLRUMap<string, number>(2);
    map.set('a', 1);
    map.set('b', 2);
    map.set('c', 3);
    expect(map.size).toBe(2);
  });

  it('evicts the least-recently-used entry', () => {
    const map = new BoundedLRUMap<string, number>(2);
    map.set('a', 1);
    map.set('b', 2);
    map.get('a'); // 'a' is now most-recently-used; 'b' becomes LRU
    map.set('c', 3); // should evict 'b', not 'a'
    expect(map.has('a')).toBe(true);
    expect(map.has('b')).toBe(false);
    expect(map.has('c')).toBe(true);
  });

  it('calls onEvict with the evicted key and value', () => {
    const evicted: Array<[string, number]> = [];
    const map = new BoundedLRUMap<string, number>(1, (k, v) => evicted.push([k, v]));
    map.set('a', 1);
    map.set('b', 2);
    expect(evicted).toEqual([['a', 1]]);
  });

  it('updating an existing key does not evict anything and refreshes recency', () => {
    const evicted: string[] = [];
    const map = new BoundedLRUMap<string, number>(2, (k) => evicted.push(k));
    map.set('a', 1);
    map.set('b', 2);
    map.set('a', 99); // update, not insert
    expect(evicted).toEqual([]);
    expect(map.get('a')).toBe(99);
    expect(map.size).toBe(2);
  });

  it('throws on non-positive capacity', () => {
    expect(() => new BoundedLRUMap(0)).toThrow();
  });
});
