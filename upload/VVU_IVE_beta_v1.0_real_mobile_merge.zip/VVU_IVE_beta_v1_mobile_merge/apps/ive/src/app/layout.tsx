import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "Evidence Independence Specification",
  description: "VVU IVE — Integrated Verification Environment backed by the Evidence Independence Specification (EIS). Evidence-bound authorization: A = C ∧ E ∧ I ∧ S ∧ R, fail-closed by Theorem 5.",
  keywords: ["VVU", "IVE", "EIS", "Evidence Independence Specification", "authorization", "participation ratio", "heat kernel", "circuit breaker", "fail-closed"],
  authors: [{ name: "VVU — Venture Vision Ubuntu" }],
  icons: {
    icon: "/logo.svg",
  },
  openGraph: {
    title: "Evidence Independence Specification",
    description: "VVU IVE — evidence-bound authorization (A = C ∧ E ∧ I ∧ S ∧ R), fail-closed.",
    siteName: "VVU IVE",
    type: "website",
  },
  twitter: {
    card: "summary_large_image",
    title: "Evidence Independence Specification",
    description: "VVU IVE — evidence-bound authorization, fail-closed.",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased bg-background text-foreground`}
      >
        {children}
        <Toaster />
      </body>
    </html>
  );
}
