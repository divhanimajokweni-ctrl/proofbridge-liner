# IEEE 29148 Code Tagging Guide
## VVU-SEARM Requirement Traceability Implementation

**Audience:** Junior Engineers, Code Reviewers, DevOps  
**Duration:** 30-minute read + hands-on implementation  
**Status:** PRODUCTION-READY  

---

## Quick Reference: The 8 Requirements

Every public function must be tagged with at least one `@REQ-XX` comment.

```
@REQ-01 → Ingest L2 bundles from Arbitrum (API Gateway, gRPC)
@REQ-02 → Detect thermal excursions within 250ms (HIP Circuit Breaker)
@REQ-03 → Tree reduction on 1M nodes in <500ms (MI300X Kernel)
@REQ-04 → Enforce 5-State Decision Matrix logic (Watchdog Decision Engine)
@REQ-05 → On FAILSAFE, deflect 100% traffic in <50ms (API Interlock)
@REQ-06 → Generate L0 Provenance Hash (FNv-1a) (Fraud Plug)
@REQ-07 → Archive to Arweave + Arbitrum calldata (Ledger Contract)
@REQ-08 → <1% instability under 10K faults (Chaos Tests)
```

---

## Part 1: TypeScript/JavaScript Functions

### Example 1: REQ-01 (Ingest Function)

**BEFORE:**
```typescript
// apps/api/watchdog.ts
async function ingestBundle(packet: L2Bundle): Promise<ValidationResult> {
  const startTime = Date.now();
  const validation = await arbitrumValidator(packet);
  return {
    valid: validation.passes,
    latency: Date.now() - startTime,
  };
}
```

**AFTER:**
```typescript
// apps/api/watchdog.ts
// @REQ-01 @REQ-04
// Ingest and validate L2 bundle pre-validation packets from live Arbitrum stream
// Verification: ingest_bundle_test.js (P99 latency < 15ms)
async function ingestBundle(packet: L2Bundle): Promise<ValidationResult> {
  const startTime = Date.now();
  const validation = await arbitrumValidator(packet);
  const latency = Date.now() - startTime;
  
  // REQ-04: Validate against 5-State Decision Matrix
  if (latency > 15) {
    logWarning(`REQ-01 SLA miss: latency ${latency}ms exceeds threshold`);
  }
  
  return {
    valid: validation.passes,
    latency,
  };
}
```

**Tagging Rules:**
- ✅ Function comment: `// @REQ-01 @REQ-04`
- ✅ Description of what the function does (one sentence max)
- ✅ Verification method cited (test file + acceptance criteria)
- ✅ If logic touches multiple requirements, tag all of them
- ✅ Use `logWarning()` or metric emission when SLA is at risk

---

### Example 2: REQ-05 (Fail-Safe Function)

**BEFORE:**
```typescript
// src/gateway/APIInterlock.ts
function triggerFailsafe(): void {
  apiGateway.blockAllTraffic();
  hardwareKillSwitch.activate();
}
```

**AFTER:**
```typescript
// src/gateway/APIInterlock.ts
// @REQ-05
// On FAILSAFE state entry, API gateway SHALL deflect 100% incoming traffic
// and trigger hardware kill-switch within 50ms
// Verification: fail_closed_test.js (100% deflection + ≤50ms latency)
// Critical: This is a safety function. Any change requires peer review + CI pass.
async function triggerFailsafe(): Promise<FailsafeResult> {
  const startTime = performance.now();
  
  try {
    // Step 1: Block all incoming traffic (must complete <25ms)
    await apiGateway.blockAllTraffic();
    const blockTime = performance.now() - startTime;
    
    if (blockTime > 25) {
      logger.error(`REQ-05 VIOLATION: blockAllTraffic took ${blockTime}ms (max 25ms)`);
      throw new Error('REQ-05 SLA violation: traffic blocking exceeded budget');
    }
    
    // Step 2: Trigger hardware kill-switch (must complete <50ms total)
    await hardwareKillSwitch.activate();
    const totalTime = performance.now() - startTime;
    
    if (totalTime > 50) {
      logger.error(`REQ-05 VIOLATION: failsafe took ${totalTime}ms (max 50ms)`);
      throw new Error('REQ-05 SLA violation: failsafe latency exceeded 50ms');
    }
    
    // Emit metric for monitoring
    metrics.emit('failsafe_latency_ms', totalTime);
    logger.info(`REQ-05 PASS: Failsafe completed in ${totalTime}ms`);
    
    return { success: true, latency: totalTime };
  } catch (error) {
    logger.error(`REQ-05 FAILURE: ${error.message}`);
    // Escalate to on-call engineer
    await escalate('REQ-05-FAILSAFE-ERROR', error);
    throw error;
  }
}
```

**Why This Matters:**
- `@REQ-05` tag makes this function searchable in compliance audits
- Verification comment links to test suite
- **Critical** note prevents casual refactoring
- Timing assertions within the function catch SLA violations in production
- Metrics emission lets you monitor compliance in real-time
- Error handling escalates REQ-05 breaches immediately

---

## Part 2: C++ / ROCm Functions

### Example 3: REQ-02 (Thermal Detection)

**BEFORE:**
```cpp
// src/drivers/vu_hip_circuit_breaker.cpp
void checkThermalState() {
  float temp = readHIPRegister(TEMP_REGISTER);
  if (temp > 3500) {  // 3.5K in millidegrees
    activateCircuitBreaker();
  }
}
```

**AFTER:**
```cpp
// src/drivers/vu_hip_circuit_breaker.cpp
// @REQ-02
// Detect hardware thermal excursions (>3.5K @ 3.2K baseline) and jitter faults 
// (>15ps) within 250ms via AMD MI300X HIP telemetry
// Verification: thermal_failure_simulation.py (chaos test)
// Source: IEEE 29148 Matrix, OV-5-02
void checkThermalState() {
  // Baseline: 3.2K (in millidegrees Kelvin)
  const float THERMAL_BASELINE_MK = 3200.0f;
  const float THERMAL_THRESHOLD_MK = 3500.0f;  // 3.5K threshold
  const int MAX_JITTER_PS = 15;  // Maximum acceptable jitter: 15 picoseconds
  const int MAX_LATENCY_MS = 250;  // REQ-02: Detect within 250ms
  
  auto start = std::chrono::high_resolution_clock::now();
  
  // Read temperature from HIP register
  float temp_mk = readHIPRegister(TEMP_REGISTER);
  int jitter_ps = readHIPRegister(JITTER_REGISTER);
  
  auto elapsed = std::chrono::high_resolution_clock::now() - start;
  int elapsed_ms = std::chrono::duration_cast<std::chrono::milliseconds>(elapsed).count();
  
  // REQ-02 SLA Check: Detection must complete within 250ms
  if (elapsed_ms > MAX_LATENCY_MS) {
    logError("REQ-02 SLA MISS: thermal detection took %dms (max %dms)", 
             elapsed_ms, MAX_LATENCY_MS);
    // Still proceed with decision to maintain safety
  }
  
  // Anomaly detection
  bool thermal_critical = (temp_mk > THERMAL_THRESHOLD_MK);
  bool jitter_critical = (jitter_ps > MAX_JITTER_PS);
  
  if (thermal_critical || jitter_critical) {
    if (thermal_critical) {
      logWarning("REQ-02: Thermal excursion detected: %.1fK (threshold %.1fK)",
                 temp_mk / 1000.0f, THERMAL_THRESHOLD_MK / 1000.0f);
    }
    if (jitter_critical) {
      logWarning("REQ-02: Jitter fault detected: %dps (threshold %dps)",
                 jitter_ps, MAX_JITTER_PS);
    }
    
    // Escalate to REQ-05 (fail-safe)
    activateCircuitBreaker();
    metrics.recordThermalAnomaly(temp_mk, jitter_ps);
  }
}
```

**C++ Tagging Rules:**
- ✅ `@REQ-XX` in the function comment block
- ✅ Named constants (never magic numbers) tied to requirements
- ✅ Timing instrumentation to verify SLA
- ✅ Error logging includes the requirement ID
- ✅ Metrics emission for production monitoring
- ✅ Comments map each constraint to the requirement

---

## Part 3: Solidity / Smart Contracts

### Example 4: REQ-07 (Archive to Chain)

**BEFORE:**
```solidity
// contracts/VVUIVELedger.sol
function recordProvenanceHash(bytes32 hash) public {
  ledger[msg.sender] = hash;
  emit ProvenanceRecorded(hash);
}
```

**AFTER:**
```solidity
// contracts/VVUIVELedger.sol
// @REQ-07
// System SHALL archive provenance state root to Arweave (permanent) 
// and Arbitrum L1 calldata (on-chain anchor) with <2s confirmation
// Verification: archive_e2e_test.js (100% success rate, <2s mean latency)
// OV-5-06: Archive to Arweave & Chain
//
// IMPORTANT: This function is part of the audit trail.
// All inputs are hashed and stored immutably. Do not modify without
// updating the IEEE 29148 requirement spec and running the full test suite.
//
// Emits: ProvenanceRecorded (indexed by txHash, timestamp, hash)
function recordProvenanceHash(
    bytes32 txHash,
    uint256 timestamp,
    bytes32 hash
) public {
    require(hash != bytes32(0), "REQ-07: Hash cannot be zero");
    require(timestamp <= block.timestamp, "REQ-07: Timestamp cannot be in future");
    
    // Record the provenance hash in the ledger (on-chain anchor)
    ledger[txHash] = hash;
    timestamps[txHash] = timestamp;
    
    // Emit event for Arweave indexing
    // Off-chain listener will pick this up and anchor to Arweave
    emit ProvenanceRecorded(txHash, timestamp, hash, block.number);
}

// @REQ-07
// Verify that a provenance hash was recorded
// Used by audit tools to confirm immutability
function verifyProvenanceHash(bytes32 txHash, bytes32 expectedHash) 
    public 
    view 
    returns (bool) 
{
    return ledger[txHash] == expectedHash;
}

event ProvenanceRecorded(
    indexed bytes32 txHash,
    uint256 timestamp,
    bytes32 hash,
    uint256 blockNumber
);
```

**Solidity Tagging Rules:**
- ✅ `@REQ-XX` in the function comment block
- ✅ Comprehensive natspec comments explaining immutability
- ✅ Input validation tied to requirements (require statements with REQ-XX)
- ✅ Events named and indexed for audit trail indexing
- ✅ View functions that verify compliance included

---

## Part 4: Scanning for Untagged Code

### Script: Find Missing Tags

Run this command to find all public functions that lack `@REQ-XX` tags:

```bash
#!/bin/bash
# find_untagged_requirements.sh
# Run from project root

echo "=== Scanning TypeScript/JavaScript functions ==="
grep -r "^\s*\(export\s\)\?\(async\s\)\?\(function\|const.*=.*=>\)" \
  --include="*.ts" --include="*.js" \
  apps/ src/ | while read line; do
  file=$(echo "$line" | cut -d: -f1)
  linenum=$(grep -n "$(echo "$line" | cut -d: -f2-)" "$file" | head -1 | cut -d: -f1)
  
  # Check if the line before has a @REQ tag
  if ! sed -n "$((linenum-5)),$((linenum-1))p" "$file" | grep -q "@REQ-"; then
    echo "⚠️  UNTAGGED: $file:$linenum"
  fi
done

echo ""
echo "=== Scanning C++ functions ==="
grep -r "^\s*\(void\|int\|bool\|float\|async\)" \
  --include="*.cpp" --include="*.h" \
  src/drivers/ | grep -v "^.*//.*@REQ-" | head -20

echo ""
echo "=== Scanning Solidity functions ==="
grep -r "^\s*\(function\|modifier\|event\)" \
  --include="*.sol" \
  contracts/ | grep -v "^.*//.*@REQ-" | head -20
```

**Usage:**
```bash
chmod +x find_untagged_requirements.sh
./find_untagged_requirements.sh
```

---

## Part 5: Code Review Checklist

Every PR must satisfy this checklist before merge:

```markdown
## IEEE 29148 Code Tagging Checklist

- [ ] All public functions have `@REQ-XX` comment tags
- [ ] At least one test case references each tagged requirement
- [ ] No requirement tag appears on more than 10 functions (scope creep flag)
- [ ] Timing/latency assertions are present if REQ involves SLA
- [ ] Error logs include requirement ID in message (e.g., "REQ-02 VIOLATION:")
- [ ] If touching REQ-02, REQ-05, or REQ-08: peer review from tech lead required
- [ ] If modifying REQ-04 (Decision Engine): notify compliance officer
- [ ] New test files created? Verify test name matches requirement ID (e.g., `REQ-01_ingest_test.js`)
```

---

## Part 6: Common Mistakes (Don't Do These)

❌ **WRONG:**
```typescript
// Generic function
function helper() {
  return Math.random();
}
```

**Why:** Helper functions should only be tagged if they directly implement a requirement. Generic utilities need not be tagged.

---

❌ **WRONG:**
```typescript
// @REQ-01 @REQ-02 @REQ-03 @REQ-04 @REQ-05 @REQ-06 @REQ-07 @REQ-08
// Do everything
function universalHandler() {
  // ...
}
```

**Why:** If a function touches >3 requirements, it's doing too much. Refactor into smaller, focused functions.

---

❌ **WRONG:**
```typescript
// @REQ-THERMAL-DETECTION
// Detect thermal anomalies
function checkTemp() {
  // ...
}
```

**Why:** Use the exact requirement ID from the matrix (e.g., `@REQ-02`), not custom names.

---

✅ **RIGHT:**
```typescript
// @REQ-01 @REQ-04
// Ingest L2 bundle and validate against decision matrix
// Verification: ingest_bundle_test.js (P99 latency < 15ms)
async function ingestAndValidateBundle(packet: L2Bundle): Promise<ValidationResult> {
  // ...
}
```

---

## Part 7: Quick Integration Test

After tagging, run this command to verify the matrix is satisfied:

```bash
# Verify REQ-01 is tagged somewhere
grep -r "@REQ-01" apps/ src/ contracts/

# Count total requirement tags
echo "Total @REQ tags found:"
grep -r "@REQ-" apps/ src/ contracts/ | wc -l

# Expected: at least 8 unique requirement IDs
echo "Unique requirements:"
grep -ro "@REQ-[0-9][0-9]" apps/ src/ contracts/ | sort -u
```

**Expected Output:**
```
@REQ-01
@REQ-02
@REQ-03
@REQ-04
@REQ-05
@REQ-06
@REQ-07
@REQ-08
```

---

## Part 8: Daily Compliance Check

Add to your CI/CD pipeline (GitHub Actions, GitLab CI, etc.):

```yaml
# .github/workflows/compliance-check.yml
name: IEEE 29148 Compliance Gate

on: [push, pull_request]

jobs:
  compliance:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v3
      
      - name: Check requirement tag coverage
        run: |
          echo "Scanning for @REQ tags..."
          TAGS=$(grep -ro "@REQ-[0-9][0-9]" apps/ src/ contracts/ | wc -l)
          echo "Found $TAGS requirement tags"
          
          # Fail if any core files lack tags
          if ! grep -q "@REQ-" apps/api/watchdog.ts; then
            echo "ERROR: Watchdog API lacks @REQ tags"
            exit 1
          fi
          
          if ! grep -q "@REQ-" src/drivers/vu_hip_circuit_breaker.cpp; then
            echo "ERROR: HIP circuit breaker lacks @REQ tags"
            exit 1
          fi
          
          if ! grep -q "@REQ-" contracts/VVUIVELedger.sol; then
            echo "ERROR: Ledger contract lacks @REQ tags"
            exit 1
          fi
          
          echo "✅ IEEE 29148 compliance gate PASSED"
```

---

## Rollout Timeline

**Day 1 (Today):**
- All engineers read this guide (30 min)
- Review the IEEE 29148 matrix
- Junior engineer runs tag scan on existing code

**Day 2:**
- Code tagging sprint (all public functions)
- Add CI/CD gate
- Run compliance check

**Day 3:**
- Code review with requirement tag checklist
- Update dashboard widget
- Final audit

---

## Questions?

- **"My function touches 2 requirements"** → Tag both (`@REQ-01 @REQ-04`)
- **"This is a private helper"** → Only tag if it directly implements a requirement
- **"What if I refactor later?"** → Update tags + run compliance check + update matrix version
- **"I broke a requirement SLA"** → Log error with requirement ID, escalate, document root cause

**Golden Rule:** *If you can't tag it with a requirement ID, it's probably not part of the specification.*

---

## Resources

- **IEEE 29148 Matrix:** `/docs/compliance/ieee_29148_matrix.md`
- **PlantUML Architecture:** `/docs/architecture/vvu_decision_engine.puml`
- **Test Suite Locations:** `tests/requirements/`
- **Compliance Dashboard:** `apps/dashboard/compliance-widget.tsx`

---

**Last Updated:** 2026-08-17  
**Maintained By:** Compliance Officer + Engineering Lead  
**Review Cycle:** Quarterly + per major release
