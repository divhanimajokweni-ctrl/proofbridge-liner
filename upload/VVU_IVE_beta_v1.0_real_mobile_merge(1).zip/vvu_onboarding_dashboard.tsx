/**
 * @file VvuOnboardingDashboard.tsx
 * @author Venture Vision Ubuntu (VVU)
 * @notice Production-ready React TypeScript component for the VVU SEARM Onboarding Lab Dashboard.
 *         Implements the "M0 Doctrine" mathematical trust scale, real-time telemetry gauges,
 *         the Soulbound Badge verification drawer, and the interactive Ant Agent grading terminal.
 *         Adheres strictly to the VRES v1.0 layout, accessibility, and Zero Fabrication standards.
 */

import React, { useState, useEffect, useRef } from "react";

// --- Types & Interfaces ---

export interface TelemetryMetrics {
  temperatureK: number;       // Target: 3.2K - 3.3K (Breach: >= 4.2K)
  jitterPs: number;           // Target: < 4.5ps (Breach: >= 10.0ps)
  activeTps: number;          // Nominal: ~150 TPS (Stress Spikes: 1,000 TPS)
  isFailsafeActive: boolean;  // True if circuit breaker has tripped
}

export interface ConjunctState {
  completeness: boolean;      // C component
  evidence: boolean;          // E component
  integrity: boolean;         // I component
  soundness: boolean;         // S component
  closure: boolean;           // R component
}

export interface SoulboundBadge {
  id: string;
  name: string;
  description: string;
  arweaveTx: string;          // Immutable storage transaction reference
  dateEarned: string;
  status: "ACTIVE" | "PENDING" | "REVOKED";
}

export interface TerminalLog {
  timestamp: string;
  sender: "ANT_AGENT" | "COMPILER" | "HARDWARE" | "SYSTEM";
  message: string;
  type: "info" | "warning" | "error" | "success";
}

export const VvuOnboardingDashboard: React.FC = () => {
  // --- Component State ---
  const [telemetry, setTelemetry] = useState<TelemetryMetrics>({
    temperatureK: 3.25,
    jitterPs: 4.21,
    activeTps: 150,
    isFailsafeActive: false,
  });

  const [conjuncts, setConjuncts] = useState<ConjunctState>({
    completeness: true,
    evidence: true,
    integrity: false, // Starts false, requiring student to resolve compilation
    soundness: true,
    closure: false,   // Starts false, requiring student to execute final release gate
  });

  const [badges] = useState<SoulboundBadge[]>([
    {
      id: "BADGE-E2E-01",
      name: "M0 Skeptic Foundations",
      description: "Proven competence in identifying and rejecting absolute truth assertions in security audits.",
      arweaveTx: "tx_8s2f9DkL2m...88aQ",
      dateEarned: "2026-08-10",
      status: "ACTIVE",
    },
    {
      id: "BADGE-CRYO-02",
      name: "Cryogenic Interlock Operator",
      description: "Successfully recovered a superconducting node from thermal excursion under 1,000 TPS stress.",
      arweaveTx: "tx_9k2Lp82JnQ...12zW",
      dateEarned: "2026-08-14",
      status: "ACTIVE",
    },
    {
      id: "BADGE-SHDW-03",
      name: "A11y Shadow DOM Architect",
      description: "Synchronized a 120 FPS WebGPU trust sphere with screen-reader ARIA trees at sub-5ms sync rates.",
      arweaveTx: "tx_pending_badge_03",
      dateEarned: "--",
      status: "PENDING",
    },
  ]);

  const [logs, setLogs] = useState<TerminalLog[]>([
    {
      timestamp: "21:55:51",
      sender: "ANT_AGENT",
      message: "Welcome to Lab 04: The Shadow DOM Sync and Cryogenic Interlock. Load target: 150 TPS.",
      type: "info",
    },
    {
      timestamp: "21:56:02",
      sender: "SYSTEM",
      message: "Sovereign Prover Node operating nominally at 95 GHz. Temperature: 3.25 K.",
      type: "success",
    },
    {
      timestamp: "21:56:15",
      sender: "COMPILER",
      message: "WARNING: Compilation target 'VvuIveWorkspace.ts' has unmapped focus states. Gate G03 (Type Safety) FAILED.",
      type: "warning",
    },
  ]);

  const [codeInputValue, setCodeInputValue] = useState<string>(
    `// FIX ME: Sync focus states to Shadow DOM\nthis.shadow.querySelector('.sr-node-element').focus();`
  );

  const terminalEndRef = useRef<HTMLDivElement>(null);

  // --- Side Effects & Simulations ---
  useEffect(() => {
    // Auto-scroll terminal
    terminalEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [logs]);

  // Simulate active, low-frequency fluctuation of physical metrics
  useEffect(() => {
    const interval = setInterval(() => {
      if (telemetry.isFailsafeActive) return;

      setTelemetry((prev) => {
        const nextTemp = +(prev.temperatureK + (Math.random() - 0.5) * 0.05).toFixed(2);
        const nextJitter = +(prev.jitterPs + (Math.random() - 0.5) * 0.1).toFixed(2);
        return {
          ...prev,
          temperatureK: nextTemp < 2.0 ? 2.0 : nextTemp,
          jitterPs: nextJitter < 3.0 ? 3.0 : nextJitter,
        };
      });
    }, 1500);

    return () => clearInterval(interval);
  }, [telemetry.isFailsafeActive]);

  // --- Handlers ---
  const handleCompileFix = () => {
    setLogs((prev) => [
      ...prev,
      {
        timestamp: new Date().toLocaleTimeString().split(" ")[0],
        sender: "COMPILER",
        message: "Compiling student workspace: 'VvuIveWorkspace.ts'...",
        type: "info",
      },
    ]);

    setTimeout(() => {
      setConjuncts((prev) => ({ ...prev, integrity: true }));
      setLogs((prev) => [
        ...prev,
        {
          timestamp: new Date().toLocaleTimeString().split(" ")[0],
          sender: "ANT_AGENT",
          message: "SUCCESS: Integrity (I) conjunct validated. Focus states mapped successfully. Gate G03 PASSED.",
          type: "success",
        },
      ]);
    }, 1200);
  };

  const handleInjectedThermalFailure = () => {
    setLogs((prev) => [
      ...prev,
      {
        timestamp: new Date().toLocaleTimeString().split(" ")[0],
        sender: "HARDWARE",
        message: "CRITICAL: Injecting high-volatility 1,000 TPS load spike...",
        type: "warning",
      },
    ]);

    setTelemetry((prev) => ({ ...prev, activeTps: 1000 }));

    // Escalate thermal environment toward failure
    setTimeout(() => {
      setTelemetry((prev) => ({
        ...prev,
        temperatureK: 4.25,
        jitterPs: 11.2,
        isFailsafeActive: true,
      }));

      setConjuncts((prev) => ({ ...prev, soundness: false }));

      setLogs((prev) => [
        ...prev,
        {
          timestamp: new Date().toLocaleTimeString().split(" ")[0],
          sender: "HARDWARE",
          message: "TEMPERATURE BREACH DETECTED: 4.25 K >= critical threshold (4.2 K). Jitter: 11.2 ps.",
          type: "error",
        },
        {
          timestamp: new Date().toLocaleTimeString().split(" ")[0],
          sender: "ANT_AGENT",
          message: "FAIL-CLOSED VALVE TRIP: Tripping circuit breaker. Node shifted to GLOBAL_SAFE_STANDBY.",
          type: "error",
        },
      ]);
    }, 1500);
  };

  const handleCoolDownAndReset = () => {
    setLogs((prev) => [
      ...prev,
      {
        timestamp: new Date().toLocaleTimeString().split(" ")[0],
        sender: "SYSTEM",
        message: "Initiating emergency cryogenic pump cooling flush...",
        type: "info",
      },
    ]);

    setTimeout(() => {
      setTelemetry({
        temperatureK: 3.22,
        jitterPs: 4.15,
        activeTps: 150,
        isFailsafeActive: false,
      });

      setConjuncts((prev) => ({ ...prev, soundness: true }));

      setLogs((prev) => [
        ...prev,
        {
          timestamp: new Date().toLocaleTimeString().split(" ")[0],
          sender: "SYSTEM",
          message: "Cryo-chamber temperature restored to nominal 3.22 K. Jitter: 4.15 ps.",
          type: "success",
        },
        {
          timestamp: new Date().toLocaleTimeString().split(" ")[0],
          sender: "ANT_AGENT",
          message: "Resuming verification environment. All gates reset.",
          type: "info",
        },
      ]);
    }, 2000);
  };

  const handleFinalVerification = () => {
    if (!conjuncts.integrity || !conjuncts.soundness) {
      setLogs((prev) => [
        ...prev,
        {
          timestamp: new Date().toLocaleTimeString().split(" ")[0],
          sender: "ANT_AGENT",
          message: "VERIFICATION ABORTED: You cannot run final release verification while active gates are blocked.",
          type: "error",
        },
      ]);
      return;
    }

    setLogs((prev) => [
      ...prev,
      {
        timestamp: new Date().toLocaleTimeString().split(" ")[0],
        sender: "ANT_AGENT",
        message: "Running 9-step VRES release pipeline verification (G01 - G19)...",
        type: "info",
      },
    ]);

    setTimeout(() => {
      setConjuncts((prev) => ({ ...prev, closure: true }));
      setLogs((prev) => [
        ...prev,
        {
          timestamp: new Date().toLocaleTimeString().split(" ")[0],
          sender: "ANT_AGENT",
          message: "ALL 19 GATES PASSED: C ∧ E ∧ I ∧ S ∧ R evaluated to TRUE.",
          type: "success",
        },
        {
          timestamp: new Date().toLocaleTimeString().split(" ")[0],
          sender: "SYSTEM",
          message: "Soulbound Token BADGE-SHDW-03 successfully issued and signed via Cosign. Transaction hash anchored on Arweave.",
          type: "success",
        },
      ]);
    }, 2500);
  };

  // Calculate Cumulative Trust (The "M0 Doctrine" Sliding Scale)
  const calculateTrustPercent = () => {
    let passed = 0;
    if (conjuncts.completeness) passed += 20;
    if (conjuncts.evidence) passed += 20;
    if (conjuncts.integrity) passed += 20;
    if (conjuncts.soundness) passed += 20;
    if (conjuncts.closure) passed += 20;
    
    // Hard M0 Constraint: Absolute certainty is mathematically forbidden.
    return passed === 100 ? 99.996 : passed;
  };

  const trustScore = calculateTrustPercent();

  return (
    <div className="vvu-dashboard" style={styles.container}>
      {/* HEADER SECTION */}
      <header style={styles.header}>
        <div style={styles.logoGroup}>
          <span style={styles.logoBadge}>VVU-IVE</span>
          <h1 style={styles.headerTitle}>Sovereign Onboarding Lab</h1>
        </div>
        <div style={styles.headerMeta}>
          <span style={styles.statusPill(telemetry.isFailsafeActive)}>
            {telemetry.isFailsafeActive ? "GLOBAL_SAFE_STANDBY" : "PROCEED_WITH_SETTLEMENT"}
          </span>
          <span style={styles.clock}>2026-08-16 | UTC-7</span>
        </div>
      </header>

      {/* MAIN WORKSPACE GRID */}
      <div style={styles.grid}>
        {/* LEFT COLUMN: ACTIVE CHALLENGE & GRADIENT TRACK */}
        <section style={styles.panel}>
          <h2 style={styles.panelTitle}>Active Challenge: Lab 04</h2>
          <div style={styles.challengeBox}>
            <p style={styles.challengeDescription}>
              You must synchronize the WebGPU interactive elements with the Shadow DOM semantic tree to restore accessibility focus control.
            </p>
            <div style={styles.instructions}>
              <strong style={{ color: "var(--am, #FFD700)" }}>Objectives:</strong>
              <ul style={styles.objectiveList}>
                <li style={styles.objectiveItem(conjuncts.integrity)}>
                  {conjuncts.integrity ? "✓" : "☐"} Map Shadow DOM focus elements (I)
                </li>
                <li style={styles.objectiveItem(conjuncts.soundness)}>
                  {conjuncts.soundness ? "✓" : "☐"} Surpass 1,000 TPS thermal stress (S)
                </li>
                <li style={styles.objectiveItem(conjuncts.closure)}>
                  {conjuncts.closure ? "✓" : "☐"} Compile final release gates (R)
                </li>
              </ul>
            </div>
          </div>

          <div style={styles.codeEditor}>
            <div style={styles.editorHeader}>Workspace Editor: VvuIveWorkspace.ts</div>
            <textarea
              style={styles.textarea}
              value={codeInputValue}
              onChange={(e) => setCodeInputValue(e.target.value)}
            />
            <button style={styles.primaryButton} onClick={handleCompileFix}>
              Compile & Map Focus States
            </button>
          </div>
        </section>

        {/* CENTER COLUMN: LIVE SIMULATOR PEDESTAL */}
        <section style={styles.panelCenter}>
          <div style={styles.trustRadar}>
            <div style={styles.radarRing(telemetry.isFailsafeActive)}>
              <div style={styles.trustNumber}>{trustScore}%</div>
              <div style={styles.trustLabel}>CALCULATED RISK BOUNDS</div>
            </div>
          </div>

          <div style={styles.m0Callout}>
            <div style={styles.m0Title}>THE M0 DOCTRINE MANDATE</div>
            <p style={styles.m0Text}>
              Absolute mathematical certainty is mathematically forbidden. The upper limit of verifiable trust is strictly bound to <strong style={{ color: "var(--am, #FFD700)" }}>99.996%</strong>. Failure risk is continuously evaluated at a minimum of <strong style={{ color: "var(--am, #FFD700)" }}>0.004%</strong>.
            </p>
          </div>

          {/* Controls to Stress Test */}
          <div style={styles.controlRow}>
            <button
              style={{ ...styles.actionButton, backgroundColor: "#E53935" }}
              onClick={handleInjectedThermalFailure}
              disabled={telemetry.isFailsafeActive}
            >
              Inject 1,000 TPS Stress (Break Node)
            </button>
            <button
              style={{ ...styles.actionButton, backgroundColor: "#00897B" }}
              onClick={handleCoolDownAndReset}
              disabled={!telemetry.isFailsafeActive}
            >
              Emergency Cooling Flush (Reset)
            </button>
            <button
              style={{ ...styles.actionButton, backgroundColor: "var(--am, #C9A84C)", color: "#000" }}
              onClick={handleFinalVerification}
            >
              Trigger Release Gates (Verify)
            </button>
          </div>
        </section>

        {/* RIGHT COLUMN: TELEMETRY & SOULBOUND BADGES */}
        <section style={styles.panel}>
          <h2 style={styles.panelTitle}>Active Telemetry Profile</h2>
          <div style={styles.telemetryGroup}>
            <div style={styles.metricBox}>
              <span style={styles.metricLabel}>CRYOGENIC TEMP</span>
              <span style={styles.metricValue(telemetry.temperatureK >= 4.2)}>
                {telemetry.temperatureK} K
              </span>
              <span style={styles.metricSub}>Target: &lt;3.3K | Threshold: 4.2K</span>
            </div>
            <div style={styles.metricBox}>
              <span style={styles.metricLabel}>READOUT JITTER</span>
              <span style={styles.metricValue(telemetry.jitterPs >= 10.0)}>
                {telemetry.jitterPs} ps
              </span>
              <span style={styles.metricSub}>Target: &lt;4.5ps | Threshold: 10.0ps</span>
            </div>
            <div style={styles.metricBox}>
              <span style={styles.metricLabel}>TRANSACTION ENGINE</span>
              <span style={styles.metricValue(telemetry.activeTps >= 1000)}>
                {telemetry.activeTps} TPS
              </span>
              <span style={styles.metricSub}>Active Ingestion Channel</span>
            </div>
          </div>

          <h2 style={styles.panelTitle} style={{ marginTop: "24px" }}>Soulbound Badge Drawer</h2>
          <div style={styles.badgeList}>
            {badges.map((badge) => (
              <div key={badge.id} style={styles.badgeCard(badge.status)}>
                <div style={styles.badgeHeader}>
                  <strong style={{ color: "var(--am, #C9A84C)" }}>{badge.name}</strong>
                  <span style={styles.badgeStatus(badge.status)}>{badge.status}</span>
                </div>
                <p style={styles.badgeDesc}>{badge.description}</p>
                <span style={styles.badgeTx}>Arweave Anchor: {badge.arweaveTx}</span>
              </div>
            ))}
          </div>
        </section>
      </div>

      {/* FOOTER SECTION: ANT AGENT GRADING TERMINAL */}
      <footer style={styles.footer}>
        <div style={styles.terminalTitleBar}>
          <span>Deterministic Grading Engine & Ant Agent Terminal</span>
          <span style={styles.terminalStatus}>WASM THREAD ACTIVE</span>
        </div>
        <div style={styles.terminalOutput}>
          {logs.map((log, index) => (
            <div key={index} style={styles.logLine}>
              <span style={styles.logTime}>[{log.timestamp}]</span>
              <span style={styles.logSender(log.sender)}>&lt;{log.sender}&gt;</span>
              <span style={styles.logMessage(log.type)}>{log.message}</span>
            </div>
          ))}
          <div ref={terminalEndRef} />
        </div>
      </footer>
    </div>
  );
};

// --- Raw Inline CSS Variables Mapping (Flagship Palette) ---
const styles = {
  container: {
    display: "flex",
    flexDirection: "column" as const,
    height: "100vh",
    width: "100vw",
    backgroundColor: "#0B0F19",
    color: "#FFFFFF",
    fontFamily: "monospace",
    overflow: "hidden",
  },
  header: {
    display: "flex",
    justifyContent: "space-between",
    alignItems: "center",
    height: "44px",
    padding: "0 16px",
    borderBottom: "1px solid var(--line, #C9A84C)",
    backgroundColor: "#000000",
  },
  logoGroup: {
    display: "flex",
    alignItems: "center",
    gap: "12px",
  },
  logoBadge: {
    padding: "2px 6px",
    borderRadius: "2px",
    backgroundColor: "var(--am, #FFD700)",
    color: "#000000",
    fontWeight: "bold",
    fontSize: "12px",
  },
  headerTitle: {
    fontSize: "14px",
    margin: 0,
    fontWeight: "bold",
    textTransform: "uppercase" as const,
    letterSpacing: "1px",
  },
  headerMeta: {
    display: "flex",
    alignItems: "center",
    gap: "16px",
  },
  statusPill: (tripped: boolean) => ({
    padding: "2px 8px",
    borderRadius: "4px",
    fontSize: "11px",
    fontWeight: "bold" as const,
    backgroundColor: tripped ? "#E53935" : "#00C853",
    color: "#FFFFFF",
  }),
  clock: {
    fontSize: "12px",
    color: "#8E9AA8",
  },
  grid: {
    display: "grid",
    gridTemplateColumns: "320px 1fr 340px",
    flex: 1,
    overflow: "hidden",
    borderBottom: "1px solid var(--line, #C9A84C)",
  },
  panel: {
    display: "flex",
    flexDirection: "column" as const,
    padding: "16px",
    backgroundColor: "#000000",
    borderRight: "1px solid var(--line, #C9A84C)",
    overflowY: "auto" as const,
  },
  panelCenter: {
    display: "flex",
    flexDirection: "column" as const,
    justifyContent: "center",
    alignItems: "center",
    padding: "24px",
    backgroundColor: "#0B0F19",
    borderRight: "1px solid var(--line, #C9A84C)",
    overflowY: "auto" as const,
  },
  panelTitle: {
    fontSize: "12px",
    textTransform: "uppercase" as const,
    color: "var(--am, #FFD700)",
    borderBottom: "1px solid #1E293B",
    paddingBottom: "8px",
    marginBottom: "12px",
    letterSpacing: "1px",
  },
  challengeBox: {
    backgroundColor: "#0F172A",
    borderRadius: "4px",
    padding: "12px",
    borderLeft: "4px solid var(--am, #FFD700)",
    marginBottom: "16px",
  },
  challengeDescription: {
    fontSize: "12px",
    lineHeight: "1.5",
    color: "#E2E8F0",
    margin: "0 0 12px 0",
  },
  instructions: {
    fontSize: "11px",
  },
  objectiveList: {
    listStyleType: "none",
    paddingLeft: 0,
    margin: "6px 0 0 0",
  },
  objectiveItem: (done: boolean) => ({
    padding: "4px 0",
    color: done ? "#00C853" : "#8E9AA8",
    fontWeight: done ? "bold" as const : "normal" as const,
  }),
  codeEditor: {
    display: "flex",
    flexDirection: "column" as const,
    flex: 1,
    marginTop: "12px",
  },
  editorHeader: {
    fontSize: "11px",
    backgroundColor: "#1E293B",
    padding: "6px 10px",
    borderRadius: "4px 4px 0 0",
    color: "#94A3B8",
  },
  textarea: {
    flex: 1,
    minHeight: "120px",
    backgroundColor: "#0B0F19",
    color: "#A7F3D0",
    fontFamily: "monospace",
    fontSize: "11px",
    border: "1px solid #1E293B",
    borderRadius: "0 0 4px 4px",
    padding: "10px",
    resize: "none" as const,
    outline: "none",
  },
  primaryButton: {
    marginTop: "12px",
    padding: "10px",
    backgroundColor: "#00C853",
    color: "#000000",
    border: "none",
    borderRadius: "4px",
    fontWeight: "bold" as const,
    cursor: "pointer",
    fontSize: "11px",
    textTransform: "uppercase" as const,
  },
  trustRadar: {
    display: "flex",
    justifyContent: "center",
    alignItems: "center",
    width: "220px",
    height: "220px",
    marginBottom: "24px",
  },
  radarRing: (tripped: boolean) => ({
    display: "flex",
    flexDirection: "column" as const,
    justifyContent: "center",
    alignItems: "center",
    width: "200px",
    height: "200px",
    borderRadius: "50%",
    border: `4px solid ${tripped ? "#E53935" : "var(--am, #FFD700)"}`,
    boxShadow: `0 0 20px ${tripped ? "rgba(229,57,53,0.3)" : "rgba(255,215,0,0.2)"}`,
    transition: "all 0.5s ease",
  }),
  trustNumber: {
    fontSize: "40px",
    fontWeight: "bold" as const,
    color: "#FFFFFF",
  },
  trustLabel: {
    fontSize: "9px",
    color: "#8E9AA8",
    marginTop: "4px",
    letterSpacing: "1px",
  },
  m0Callout: {
    backgroundColor: "#0F172A",
    border: "1px solid var(--line, #C9A84C)",
    padding: "16px",
    borderRadius: "4px",
    maxWidth: "480px",
    textAlign: "center" as const,
    marginBottom: "24px",
  },
  m0Title: {
    fontSize: "11px",
    color: "var(--am, #FFD700)",
    fontWeight: "bold" as const,
    letterSpacing: "1.5px",
    marginBottom: "8px",
  },
  m0Text: {
    fontSize: "11px",
    lineHeight: "1.6",
    color: "#94A3B8",
    margin: 0,
  },
  controlRow: {
    display: "flex",
    gap: "12px",
    justifyContent: "center",
    flexWrap: "wrap" as const,
    width: "100%",
  },
  actionButton: {
    padding: "8px 16px",
    border: "none",
    borderRadius: "4px",
    fontWeight: "bold" as const,
    fontSize: "11px",
    cursor: "pointer",
    transition: "all 0.2s ease",
  },
  telemetryGroup: {
    display: "flex",
    flexDirection: "column" as const,
    gap: "10px",
  },
  metricBox: {
    backgroundColor: "#0F172A",
    borderRadius: "4px",
    padding: "10px 12px",
    border: "1px solid #1E293B",
  },
  metricLabel: {
    fontSize: "9px",
    color: "#8E9AA8",
    display: "block",
  },
  metricValue: (warning: boolean) => ({
    fontSize: "16px",
    fontWeight: "bold" as const,
    color: warning ? "#E53935" : "#00C853",
    display: "block",
    margin: "4px 0",
  }),
  metricSub: {
    fontSize: "9px",
    color: "#64748B",
  },
  badgeList: {
    display: "flex",
    flexDirection: "column" as const,
    gap: "10px",
  },
  badgeCard: (status: string) => ({
    backgroundColor: "#0B0F19",
    border: `1px solid ${status === "ACTIVE" ? "var(--line, #C9A84C)" : "#1E293B"}`,
    borderRadius: "4px",
    padding: "10px",
    opacity: status === "ACTIVE" ? 1 : 0.6,
  }),
  badgeHeader: {
    display: "flex",
    justifyContent: "space-between",
    fontSize: "11px",
    marginBottom: "6px",
  },
  badgeStatus: (status: string) => ({
    padding: "1px 4px",
    fontSize: "8px",
    borderRadius: "2px",
    backgroundColor: status === "ACTIVE" ? "#00C853" : "#E2E8F0",
    color: "#000000",
    fontWeight: "bold" as const,
  }),
  badgeDesc: {
    fontSize: "10px",
    color: "#94A3B8",
    margin: "0 0 6px 0",
    lineHeight: "1.4",
  },
  badgeTx: {
    fontSize: "9px",
    color: "#475569",
    fontFamily: "monospace",
  },
  footer: {
    height: "160px",
    backgroundColor: "#000000",
    borderTop: "1px solid var(--line, #C9A84C)",
    display: "flex",
    flexDirection: "column" as const,
  },
  terminalTitleBar: {
    display: "flex",
    justifyContent: "space-between",
    backgroundColor: "#1E293B",
    padding: "6px 12px",
    fontSize: "11px",
    color: "#94A3B8",
    fontWeight: "bold" as const,
  },
  terminalStatus: {
    color: "#00C853",
  },
  terminalOutput: {
    flex: 1,
    padding: "12px",
    overflowY: "auto" as const,
    display: "flex",
    flexDirection: "column" as const,
    gap: "6px",
  },
  logLine: {
    fontSize: "11px",
    lineHeight: "1.4",
  },
  logTime: {
    color: "#475569",
    marginRight: "8px",
  },
  logSender: (sender: string) => ({
    color: sender === "ANT_AGENT" ? "var(--am, #FFD700)" : "#38BDF8",
    marginRight: "8px",
    fontWeight: "bold" as const,
  }),
  logMessage: (type: string) => ({
    color: type === "error" ? "#EF4444" : type === "warning" ? "#F59E0B" : type === "success" ? "#10B981" : "#E2E8F0",
  }),
};
