/**
 * Vision-Language Model Prompt Engineering for Visual QA
 *
 * PHILOSOPHY:
 * - Specificity beats generality
 * - Structured output beats prose
 * - Confidence scoring enables filtering
 * - Domain knowledge reduces hallucination
 *
 * This module provides carefully crafted prompts for each dashboard section.
 * Each prompt is designed to:
 * 1. Detect real visual defects (text overflow, overlap, color semantics)
 * 2. Avoid false positives (hallucinated issues that don't exist)
 * 3. Return structured JSON for programmatic parsing
 * 4. Rate confidence so we can filter low-confidence results
 */

export type DefectType =
  | "text_overflow"
  | "text_truncation"
  | "element_overlap"
  | "misalignment"
  | "color_semantic"
  | "contrast_issue"
  | "responsive_failure"
  | "visual_clutter";

export interface VisualDefect {
  type: DefectType;
  location: string; // e.g., "top-left", "center-panel", "sidebar"
  description: string; // Specific observation
  severity: "critical" | "major" | "minor";
  confidence: number; // 0.0 to 1.0
}

export interface VLMAnalysisResult {
  status: "OK" | "DEFECTS_FOUND";
  defects: VisualDefect[];
  overallQuality: number; // 0.0 to 1.0
  analysisTime: number; // milliseconds
  model: string; // e.g., "gpt-4-vision", "claude-3-vision"
}

// ============================================================================
// System Prompt (applies to all sections)
// ============================================================================

export const SYSTEM_PROMPT = `You are a specialized UI/UX quality auditor for a distributed systems dashboard.

Your role:
- Detect visual defects in dashboard screenshots
- Be specific about locations and issues
- Assign confidence scores based on certainty
- Return structured JSON (never prose)

What you should catch:
1. Text Overflow: Text extending beyond container boundaries
2. Text Truncation: Text cut off with ellipsis but content is important
3. Element Overlap: Buttons, labels, icons overlapping each other
4. Misalignment: Elements not aligned to grid or each other
5. Color Semantics: Colors conveying wrong meaning (red=safe, green=error)
6. Contrast Issues: Text not readable against background
7. Responsive Failures: Layout breaking on different viewport sizes
8. Visual Clutter: Too many elements competing for attention

Guidelines:
- Be conservative: only flag issues you're very sure about
- Ignore minor pixel-level misalignments (<2px)
- Consider context: a small overflow in a dense data table is different from one in a control panel
- Assign higher confidence for objective issues (color, contrast) vs subjective (alignment)

CRITICAL: Respond ONLY with valid JSON. No markdown, no explanation, no preamble.`;

// ============================================================================
// Section-Specific Prompts
// ============================================================================

export const SECTION_PROMPTS: Record<string, string> = {
  overview: `
You are analyzing the Dashboard Overview page.

AREA OF FOCUS:
- KPI cards at top (showing system health metrics)
- Statistics panel (timeline, merge counts, repair operations)
- Recent activity feed
- Global controls (filters, export buttons)

SPECIFIC CHECKS:
1. Are KPI numbers (e.g., "42", "127") fully visible or truncated?
2. Do the metric labels (e.g., "Total Policies") wrap awkwardly?
3. Are the KPI cards evenly spaced and aligned?
4. Are color indicators for status (green/red/yellow) semantically correct?
   - Green = healthy/nominal
   - Red = error/critical
   - Yellow = warning/attention needed
5. Is the activity feed timestamp readable?
6. Do any badges have text that's cut off?
7. Is there horizontal scroll (which shouldn't exist at 1280px viewport)?

EXPECTED LAYOUT:
- Top: 3-4 KPI cards, each ~300px wide
- Middle: Statistics/timeline visualization
- Bottom: Recent activity list
- Right sidebar: Global filters and export controls

Return JSON with defects array. High confidence for color/text issues.`,

  studio: `
You are analyzing the Policy DSL Studio editor page.

AREA OF FOCUS:
- Left panel: Policy file tree/navigator
- Center panel: Code editor with syntax highlighting
- Right panel: Compilation errors/warnings and validation results
- Bottom: Output console

SPECIFIC CHECKS:
1. Does the editor content fit within the viewport without horizontal scroll?
2. Are lines of code visible up to 80-100 characters without wrapping awkwardly?
3. Is syntax highlighting applied correctly? (keywords should be colored differently from strings)
4. Are error messages fully visible (not cut off at the edge)?
5. Are line numbers aligned with code?
6. Do error highlight underlines extend beyond the text?
7. Is the file tree properly indented and readable?
8. Are long file paths truncated with tooltips (not showing full path)?

EXPECTED LAYOUT:
- Editor width: ~800px, height: ~600px
- Line numbers: left side, fixed width
- Errors panel: right side or bottom, collapsible

Return JSON with defects array. High confidence for truncation of error messages.`,

  topology: `
You are analyzing the DAG Topology visualization page.

AREA OF FOCUS:
- Central d3-force directed graph showing policies, agents, and state
- Node labels (text next to circles)
- Edge lines (links between nodes)
- Legend (explaining node types and colors)
- Zoom/pan controls

SPECIFIC CHECKS:
1. Do node labels overlap with other nodes or edges?
2. Are any node labels truncated or illegible?
3. Do nodes cluster too tightly (should be 60px+ apart)?
4. Are node colors semantically correct?
   - Blue = Policy
   - Green = Agent
   - Orange = State
   - Red = Error/Violation
5. Are edge lines clean and not obscuring node labels?
6. Is the legend visible and not overlapping the graph?
7. Are zoom/pan controls positioned clearly (not over the graph)?
8. Is there clear visual hierarchy (important nodes larger/darker)?
9. Do node shadows/glows extend beyond expected bounds?

FORCE SIMULATION QUALITY:
- Nodes should be well-separated
- No apparent "jitter" or instability
- Layout should look intentional, not random

Return JSON with defects array. High confidence for node overlap.`,

  federation: `
You are analyzing the Federation View showing cross-organizational reconciliation.

AREA OF FOCUS:
- Organization tree/hierarchy on the left
- State reconciliation status in the center
- Trust indicators and cross-org channels
- Gossip animation (if applicable)
- Animated state convergence visualization

SPECIFIC CHECKS:
1. Are long organization names truncated (common issue)?
   - Org names should be fully visible or have tooltips
2. Is the state value visible for each org?
3. Are trust indicators (colors) correct?
   - Green = trusted/converged
   - Yellow = in-progress reconciliation
   - Red = conflict/divergence
4. Do animated flows (if present) distract from reading static content?
5. Is the hierarchy tree properly indented?
6. Are timestamps aligned and readable?
7. Is there enough contrast between org names and background?
8. Do conflict indicators stand out visually?

ANIMATION QUALITY (if applicable):
- Gossip messages should animate smoothly
- No flashing or rapid color changes
- Convergence visualization should be clear

Return JSON with defects array. High confidence for truncated org names.`,

  studio_advanced: `
You are analyzing the Advanced Studio Features.

AREA OF FOCUS:
- Policy diff viewer (side-by-side comparison)
- Constraint graph visualization
- Performance profiling charts
- Invariant editor

SPECIFIC CHECKS:
1. In diff view: Are added/removed lines clearly marked (green/red)?
2. Are long lines in diff view readable or do they scroll?
3. Are constraint graphs legible or too dense?
4. Do variable names in constraints wrap awkwardly?
5. Are section headers properly aligned?
6. Do expandable sections have clear +/- indicators?
7. Are charts responsive to viewport size?
8. Do charts' axis labels overlap with data?

Return JSON with defects array. High confidence for color coding of diffs.`,

  proofs: `
You are analyzing the ZK Proofs verification page.

AREA OF FOCUS:
- Proof verification history table
- Proof details panel
- Constraint graph visualization
- Verification key registry

SPECIFIC CHECKS:
1. Is the proof ID column wide enough? (Long hex IDs truncating?)
2. Are verification status indicators (checkmarks, X) visible?
3. Are timestamps fully visible and aligned?
4. Is the constraint graph readable?
5. Do circuit parameter values display fully or truncate?
6. Are column headers aligned with data?
7. Is there enough vertical space between rows?
8. Do hover tooltips appear without obscuring other data?
9. Are status colors semantically correct (green=verified, red=failed)?

TABLE LAYOUT CHECKS:
- No horizontal scroll (if viewing in <1280px)
- Text not overlapping columns
- Row heights consistent

Return JSON with defects array. High confidence for ID truncation and color issues.`,

  miner: `
You are analyzing the Invariant Miner page.

AREA OF FOCUS:
- Violation history timeline
- Drift patterns visualization
- Candidate invariant proposals table
- Invariant suggestion panel

SPECIFIC CHECKS:
1. Are violation timestamps readable in timeline?
2. Do proposed invariants display their expressions fully?
3. Are confidence scores (0.0-1.0) visible?
4. Is the violation pattern chart clear or cluttered?
5. Are action buttons (accept/reject) easily accessible?
6. Do long invariant expressions wrap awkwardly?
7. Is the violation count visible for each pattern?
8. Are status indicators (new/reviewed/accepted) clear?

VISUALIZATION QUALITY:
- Timeline should not be overcrowded
- Heatmap (if used) should be colorblind-safe
- Patterns should be distinct and not overlapping

Return JSON with defects array. High confidence for text wrapping issues.`,

  audit: `
You are analyzing the Audit Report page.

AREA OF FOCUS:
- Compliance checklist (pass/fail indicators)
- Policy audit table
- Compliance signals and scores
- Export buttons (CSV, PDF, JSON)

SPECIFIC CHECKS:
1. Are pass/fail indicators (✓/✗) clearly visible?
2. Are policy names fully visible or truncated?
3. Are compliance percentages visible and readable?
4. Do audit timestamps align in the table?
5. Are export button labels clear and clickable?
6. Is there sufficient contrast for readability?
7. Do section headers clearly separate different compliance areas?
8. Are violations/findings clearly marked?
9. Can the table scroll horizontally if needed without hiding key columns?

TABLE QUALITY:
- No overlapping text
- Columns properly sized
- Row striping (if used) aids readability

Return JSON with defects array. High confidence for alignment issues.`,

  timeline: `
You are analyzing the Historical Replay Timeline page.

AREA OF FOCUS:
- Chronological event feed
- 24-hour histogram chart
- Event player/scrubber controls
- Event detail panel

SPECIFIC CHECKS:
1. Is the timeline clearly marked with time intervals?
2. Are event timestamps readable and properly aligned?
3. Does the histogram show peaks and valleys clearly?
4. Are axis labels on the histogram visible and not overlapping?
5. Do event icons (in the feed) have enough whitespace around them?
6. Is the event detail panel readable without horizontal scroll?
7. Are player controls (play/pause/seek) visually clear?
8. Does the scrubber thumb align with the timeline?
9. Are "now" and "then" time indicators (if shown) distinct?

ANIMATION/INTERACTION:
- Timeline scrubber should respond smoothly
- No jumpy or jerky movement
- Event loading should be fast

Return JSON with defects array. High confidence for alignment and overlaps.`,
};

// ============================================================================
// Base Prompt Generator
// ============================================================================

export function generateVLMPrompt(section: string): string {
  const sectionPrompt = SECTION_PROMPTS[section] || SECTION_PROMPTS.overview;

  return `${SYSTEM_PROMPT}

SECTION TO ANALYZE: ${section.toUpperCase()}

${sectionPrompt}

RESPONSE FORMAT (STRICT JSON):
{
  "status": "OK" | "DEFECTS_FOUND",
  "defects": [
    {
      "type": "${Object.values(DefectType).join(' | ')}",
      "location": "string describing where in the UI",
      "description": "specific observation",
      "severity": "critical" | "major" | "minor",
      "confidence": 0.0 to 1.0
    }
  ],
  "overallQuality": 0.0 to 1.0
}`;
}

// ============================================================================
// Confidence Filtering
// ============================================================================

/**
 * Determine if a defect should block CI/QA
 * Only high-confidence issues should fail the build
 */
export function isActionableDefect(defect: VisualDefect): boolean {
  // Critical issues: only if 85%+ confident
  if (defect.severity === "critical" && defect.confidence >= 0.85) {
    return true;
  }

  // Major issues: only if 90%+ confident
  if (defect.severity === "major" && defect.confidence >= 0.9) {
    return true;
  }

  // Minor issues: very high bar (95%+, rare)
  if (defect.severity === "minor" && defect.confidence >= 0.95) {
    return true;
  }

  return false;
}

/**
 * Filter VLM results to only actionable defects
 */
export function filterActionableDefects(result: VLMAnalysisResult): VisualDefect[] {
  return result.defects.filter(isActionableDefect);
}

// ============================================================================
// Objective vs Subjective Scoring
// ============================================================================

/**
 * Boost confidence for objective issues (things we can verify algorithmically)
 * Lower confidence for subjective issues (aesthetic judgments)
 */
export function recalibrateConfidence(defect: VisualDefect): VisualDefect {
  const objectiveTypes: DefectType[] = [
    "text_overflow",
    "text_truncation",
    "color_semantic",
    "contrast_issue",
  ];

  const subjectiveTypes: DefectType[] = ["visual_clutter", "misalignment"];

  if (objectiveTypes.includes(defect.type)) {
    // Boost confidence for objective issues
    // (VLM is generally accurate for these)
    defect.confidence = Math.min(1.0, defect.confidence * 1.2);
  }

  if (subjectiveTypes.includes(defect.type)) {
    // Lower confidence for subjective issues
    // (More prone to hallucination)
    defect.confidence = Math.max(0.0, defect.confidence * 0.8);
  }

  return defect;
}

// ============================================================================
// Examples of Good Defects vs False Positives
// ============================================================================

export const EXAMPLES = {
  goodDefects: [
    {
      type: "text_truncation" as DefectType,
      location: "Federation View, organization names",
      description:
        'Organization name "International-Weather-Monitoring-Protocol" shows as "International-Weather-Mo..." in the tree',
      severity: "major" as const,
      confidence: 0.95,
      why: "Objectively verifiable: text is cut with ellipsis but content is available",
    },
    {
      type: "color_semantic" as DefectType,
      location: "Overview page, KPI status indicators",
      description:
        "Metric showing 'System Healthy' uses RED background color (should be GREEN)",
      severity: "critical" as const,
      confidence: 0.99,
      why: "Objectively verifiable: color is simply wrong",
    },
    {
      type: "element_overlap" as DefectType,
      location: "DAG Topology, center view",
      description:
        "Node labeled 'repair-service' overlaps with edge line to 'state-node', node label is illegible",
      severity: "major" as const,
      confidence: 0.9,
      why: "Objectively verifiable: nodes can be measured as overlapping",
    },
  ],

  falsePositives: [
    {
      type: "misalignment" as DefectType,
      location: "Policy editor, line numbers",
      description: "Line numbers appear to be 1px off center",
      severity: "minor" as const,
      confidence: 0.4, // LOW: subjective, sub-pixel, invisible to users
      why: "Objectively harmless: <2px misalignment is imperceptible",
    },
    {
      type: "visual_clutter" as DefectType,
      location: "Audit report table",
      description: "Too many compliance indicators in each row make the page look busy",
      severity: "minor" as const,
      confidence: 0.2, // LOW: purely subjective, no objective problem
      why: "Subjective: 'busy' is in the eye of the beholder, not a usability defect",
    },
  ],
};

// ============================================================================
// Debugging: Print prompt for a section
// ============================================================================

export function debugPrintPrompt(section: string): void {
  console.log(`\n${"=".repeat(70)}`);
  console.log(`VLM Prompt for section: ${section.toUpperCase()}`);
  console.log(`${"=".repeat(70)}\n`);
  console.log(generateVLMPrompt(section));
  console.log(`\n${"=".repeat(70)}\n`);
}
