/**
 * DAG Layout Web Worker Implementation
 *
 * This runs in a separate thread and performs the expensive force simulation.
 * Main thread remains responsive during computation.
 *
 * FORCE SIMULATION STRATEGY:
 * - forceLink: Attract connected nodes (maintains edge integrity)
 * - forceManyBody: Repel all nodes (prevents clustering)
 * - forceCollide: Prevent exact overlaps (based on node size + label width)
 * - forceCenter: Keep layout centered
 * - Tick until alpha = 0 (complete convergence)
 */

type DAGNode = {
  id: string;
  label: string;
  type: "policy" | "agent" | "state" | "repair";
  size?: number;
  metadata?: Record<string, unknown>;
  x?: number;
  y?: number;
  vx?: number;
  vy?: number;
};

type DAGLink = {
  source: string | DAGNode;
  target: string | DAGNode;
  weight?: number;
  type?: "depends" | "produces" | "repairs";
};

type LayoutPosition = {
  id: string;
  x: number;
  y: number;
  vx?: number;
  vy?: number;
};

type LayoutResult = {
  positions: LayoutPosition[];
  bounds: {
    minX: number;
    maxX: number;
    minY: number;
    maxY: number;
    width: number;
    height: number;
  };
  metadata: {
    iterations: number;
    alpha: number;
    convergedAt: number;
    timestamp: string;
  };
};

// Simple d3-force implementation (replacing d3-force library)
class ForceSimulation {
  private nodes: DAGNode[] = [];
  private links: DAGLink[] = [];
  private forces: Array<(alpha: number) => void> = [];
  private alpha: number = 1;
  private alphaMin: number = 0.001;
  private alphaDecay: number = 0.0228; // d3-force default
  private alphaTarget: number = 0;
  private velocity: number = 0;
  private iterations: number = 0;

  setNodes(nodes: DAGNode[]): this {
    this.nodes = nodes.map((d, i) => ({
      ...d,
      x: d.x ?? Math.random() * 100,
      y: d.y ?? Math.random() * 100,
      vx: d.vx ?? 0,
      vy: d.vy ?? 0,
    }));
    return this;
  }

  setLinks(links: DAGLink[]): this {
    this.links = links;
    return this;
  }

  // Add a link force (attractive)
  forceLink(strength: number = 30): this {
    const nodeMap = new Map(this.nodes.map((n) => [n.id, n]));

    this.forces.push(() => {
      for (const link of this.links) {
        const sourceId = typeof link.source === "string" ? link.source : link.source.id;
        const targetId = typeof link.target === "string" ? link.target : link.target.id;

        const source = nodeMap.get(sourceId);
        const target = nodeMap.get(targetId);

        if (!source || !target) continue;

        const dx = (target.x ?? 0) - (source.x ?? 0);
        const dy = (target.y ?? 0) - (source.y ?? 0);
        const distance = Math.sqrt(dx * dx + dy * dy) || 0.1;

        const desiredDistance = 100 + (link.weight || 0) * 50;
        const force = (distance - desiredDistance) / distance;

        const fx = (force * dx * strength) / 2;
        const fy = (force * dy * strength) / 2;

        source.vx = (source.vx ?? 0) + fx;
        source.vy = (source.vy ?? 0) + fy;
        target.vx = (target.vx ?? 0) - fx;
        target.vy = (target.vy ?? 0) - fy;
      }
    });

    return this;
  }

  // Add a many-body force (repulsive)
  forceManyBody(strength: number = -300): this {
    this.forces.push(() => {
      for (let i = 0; i < this.nodes.length; i++) {
        for (let j = i + 1; j < this.nodes.length; j++) {
          const a = this.nodes[i];
          const b = this.nodes[j];

          const dx = (b.x ?? 0) - (a.x ?? 0);
          const dy = (b.y ?? 0) - (a.y ?? 0);
          const distSq = dx * dx + dy * dy || 1;
          const dist = Math.sqrt(distSq);

          const force = (strength / distSq) * 0.5; // Reduced strength

          const fx = (force * dx) / dist;
          const fy = (force * dy) / dist;

          a.vx = (a.vx ?? 0) - fx;
          a.vy = (a.vy ?? 0) - fy;
          b.vx = (b.vx ?? 0) + fx;
          b.vy = (b.vy ?? 0) + fy;
        }
      }
    });

    return this;
  }

  // Add a collision force (prevents overlap)
  forceCollide(radius: (d: DAGNode) => number = () => 30): this {
    this.forces.push(() => {
      for (let i = 0; i < this.nodes.length; i++) {
        for (let j = i + 1; j < this.nodes.length; j++) {
          const a = this.nodes[i];
          const b = this.nodes[j];

          const dx = (b.x ?? 0) - (a.x ?? 0);
          const dy = (b.y ?? 0) - (a.y ?? 0);
          const distance = Math.sqrt(dx * dx + dy * dy) || 1;

          const minDistance = radius(a) + radius(b);

          if (distance < minDistance) {
            const force = (minDistance - distance) / distance * 0.5;

            const fx = (force * dx) / 2;
            const fy = (force * dy) / 2;

            a.vx = (a.vx ?? 0) - fx;
            a.vy = (a.vy ?? 0) - fy;
            b.vx = (b.vx ?? 0) + fx;
            b.vy = (b.vy ?? 0) + fy;
          }
        }
      }
    });

    return this;
  }

  // Add a center force (keeps layout centered)
  forceCenter(x: number, y: number, strength: number = 0.1): this {
    this.forces.push(() => {
      let sx = 0,
        sy = 0;

      for (const node of this.nodes) {
        sx += node.x ?? 0;
        sy += node.y ?? 0;
      }

      sx = (sx / this.nodes.length - x) * strength;
      sy = (sy / this.nodes.length - y) * strength;

      for (const node of this.nodes) {
        node.vx = (node.vx ?? 0) - sx;
        node.vy = (node.vy ?? 0) - sy;
      }
    });

    return this;
  }

  // Run simulation until convergence
  tick(numTicks: number = 1): this {
    for (let t = 0; t < numTicks; t++) {
      // Apply all forces
      this.alpha += (this.alphaTarget - this.alpha) * this.alphaDecay;

      for (const force of this.forces) {
        force(this.alpha);
      }

      // Damping (friction)
      const dampFactor = 0.9;

      // Update positions
      for (const node of this.nodes) {
        node.vx = (node.vx ?? 0) * dampFactor;
        node.vy = (node.vy ?? 0) * dampFactor;

        node.x = (node.x ?? 0) + (node.vx ?? 0);
        node.y = (node.y ?? 0) + (node.vy ?? 0);
      }

      this.iterations++;
    }

    return this;
  }

  isConverged(): boolean {
    return this.alpha < this.alphaMin;
  }

  getAlpha(): number {
    return this.alpha;
  }

  getNodes(): DAGNode[] {
    return this.nodes;
  }

  getIterations(): number {
    return this.iterations;
  }
}

// ============================================================================
// Main Worker Logic
// ============================================================================

self.onmessage = (event: MessageEvent) => {
  const startTime = Date.now();

  try {
    const { nodes, links, width, height, iterations } = event.data as {
      nodes: DAGNode[];
      links: DAGLink[];
      width: number;
      height: number;
      iterations: number;
    };

    // Initialize simulation
    const sim = new ForceSimulation();

    sim
      .setNodes(nodes)
      .setLinks(links)
      .forceLink(30)
      .forceManyBody(-300)
      .forceCollide((d) => {
        // Collision radius = node size + label width estimate
        const baseRadius = d.size ?? 20;
        const labelWidth = (d.label?.length ?? 0) * 4;
        return Math.max(baseRadius, labelWidth / 2) + 10; // +10 padding
      })
      .forceCenter(width / 2, height / 2, 0.1);

    // Converge: run until alpha is below threshold
    let ticks = 0;
    while (!sim.isConverged() && ticks < iterations) {
      sim.tick(1);
      ticks++;
    }

    const convergedAt = Date.now() - startTime;

    // Extract final positions
    const finalNodes = sim.getNodes();
    const positions: LayoutPosition[] = finalNodes.map((n) => ({
      id: n.id,
      x: n.x ?? 0,
      y: n.y ?? 0,
      vx: n.vx,
      vy: n.vy,
    }));

    // Calculate bounds
    let minX = Infinity,
      maxX = -Infinity,
      minY = Infinity,
      maxY = -Infinity;

    for (const pos of positions) {
      minX = Math.min(minX, pos.x);
      maxX = Math.max(maxX, pos.x);
      minY = Math.min(minY, pos.y);
      maxY = Math.max(maxY, pos.y);
    }

    const result: LayoutResult = {
      positions,
      bounds: {
        minX,
        maxX,
        minY,
        maxY,
        width: maxX - minX || 1,
        height: maxY - minY || 1,
      },
      metadata: {
        iterations: sim.getIterations(),
        alpha: sim.getAlpha(),
        convergedAt,
        timestamp: new Date().toISOString(),
      },
    };

    self.postMessage(result);
  } catch (error) {
    const errorMsg = error instanceof Error ? error.message : String(error);
    self.postMessage({ error: `Layout computation failed: ${errorMsg}` });
  }
};
