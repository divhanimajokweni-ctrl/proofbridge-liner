/**
 * DAG Layout Pre-computation via Web Worker
 *
 * PROBLEM SOLVED:
 * - d3-force simulation runs on the main thread, blocking UI
 * - Jittery node movements create visual instability
 * - Layout is non-deterministic (same data → different layouts)
 *
 * SOLUTION:
 * - Offload force simulation to a Web Worker
 * - Run simulation until complete convergence (alpha = 0)
 * - Return static positions to main thread
 * - User can still drag nodes (overrides computed positions)
 *
 * RESULT:
 * - Smooth, deterministic, predictable layouts
 * - No UI blocking during heavy computation
 * - Testable: output is static and reproducible
 */

export interface DAGNode {
  id: string;
  label: string;
  type: "policy" | "agent" | "state" | "repair";
  size?: number;
  metadata?: Record<string, unknown>;
}

export interface DAGLink {
  source: string | DAGNode;
  target: string | DAGNode;
  weight?: number;
  type?: "depends" | "produces" | "repairs";
}

export interface LayoutPosition {
  id: string;
  x: number;
  y: number;
  vx?: number;
  vy?: number;
}

export interface LayoutResult {
  positions: LayoutPosition[];
  bounds: {
    minX: number;
    maxX: number;
    minY: number;
    maxY: number;
    width: number;
    height: number;
  };
  metadata: {
    iterations: number;
    alpha: number;
    convergedAt: number; // ms
    timestamp: string;
  };
}

/**
 * Compute DAG layout using a Web Worker
 * Non-blocking: returns a Promise
 */
export async function computeDAGLayout(
  nodes: DAGNode[],
  links: DAGLink[],
  options?: {
    width?: number;
    height?: number;
    iterations?: number;
    timeout?: number;
  }
): Promise<LayoutResult> {
  return new Promise((resolve, reject) => {
    const timeout = options?.timeout || 30000; // 30 second timeout

    const worker = new Worker(
      new URL("./dag-layout-worker-impl.js", import.meta.url),
      { type: "module" }
    );

    const timeoutId = setTimeout(() => {
      worker.terminate();
      reject(new Error("DAG layout computation timeout"));
    }, timeout);

    const handleMessage = (e: MessageEvent<LayoutResult | { error: string }>) => {
      clearTimeout(timeoutId);
      worker.terminate();

      if ("error" in e.data) {
        reject(new Error(e.data.error));
      } else {
        resolve(e.data as LayoutResult);
      }
    };

    const handleError = (err: ErrorEvent) => {
      clearTimeout(timeoutId);
      worker.terminate();
      reject(err);
    };

    worker.onmessage = handleMessage;
    worker.onerror = handleError;

    // Send computation request to worker
    worker.postMessage({
      nodes,
      links,
      width: options?.width || 1200,
      height: options?.height || 800,
      iterations: options?.iterations || 300,
    });
  });
}

/**
 * Caching layer for layout results
 * Avoids recomputation if graph structure hasn't changed
 */
export class LayoutCache {
  private cache = new Map<string, LayoutResult>();

  private hashGraph(nodes: DAGNode[], links: DAGLink[]): string {
    // Simple hash: node IDs + link structure
    const nodeIds = nodes.map((n) => n.id).sort().join("|");
    const linkPairs = links
      .map((l) => {
        const sourceId = typeof l.source === "string" ? l.source : l.source.id;
        const targetId = typeof l.target === "string" ? l.target : l.target.id;
        return `${sourceId}-${targetId}`;
      })
      .sort()
      .join("|");

    return `${nodeIds}:${linkPairs}`;
  }

  async get(
    nodes: DAGNode[],
    links: DAGLink[],
    options?: Parameters<typeof computeDAGLayout>[2]
  ): Promise<LayoutResult> {
    const hash = this.hashGraph(nodes, links);

    if (this.cache.has(hash)) {
      console.debug(`[LayoutCache] HIT for graph with ${nodes.length} nodes`);
      return this.cache.get(hash)!;
    }

    console.debug(`[LayoutCache] MISS for graph with ${nodes.length} nodes, computing...`);
    const result = await computeDAGLayout(nodes, links, options);

    this.cache.set(hash, result);
    return result;
  }

  clear() {
    this.cache.clear();
  }

  size() {
    return this.cache.size;
  }
}

/**
 * Utility: Normalize positions to a bounding box
 * Ensures layout is centered and scales well to viewport
 */
export function normalizeBounds(
  positions: LayoutPosition[],
  targetWidth: number = 1200,
  targetHeight: number = 800,
  padding: number = 40
): LayoutPosition[] {
  if (positions.length === 0) return positions;

  // Find current bounds
  let minX = Infinity,
    maxX = -Infinity,
    minY = Infinity,
    maxY = -Infinity;

  for (const pos of positions) {
    minX = Math.min(minX, pos.x);
    maxX = Math.max(maxX, pos.x);
    minY = Math.min(minY, pos.y);
    maxY = Math.max(maxY, pos.y);
  }

  const currentWidth = maxX - minX || 1;
  const currentHeight = maxY - minY || 1;

  // Scale to fit target, leaving padding
  const availWidth = targetWidth - 2 * padding;
  const availHeight = targetHeight - 2 * padding;

  const scaleX = availWidth / currentWidth;
  const scaleY = availHeight / currentHeight;
  const scale = Math.min(scaleX, scaleY, 1); // Don't upscale

  // Normalize and center
  const centerX = padding + availWidth / 2;
  const centerY = padding + availHeight / 2;

  return positions.map((pos) => ({
    ...pos,
    x: centerX + (pos.x - minX - currentWidth / 2) * scale,
    y: centerY + (pos.y - minY - currentHeight / 2) * scale,
  }));
}

/**
 * Utility: Check if layout is "stable" (suitable for rendering)
 * Layout stability indicates low ongoing velocity
 */
export function isLayoutStable(
  positions: LayoutPosition[],
  velocityThreshold: number = 0.1
): boolean {
  return positions.every((pos) => {
    const vx = pos.vx || 0;
    const vy = pos.vy || 0;
    const velocity = Math.sqrt(vx * vx + vy * vy);
    return velocity < velocityThreshold;
  });
}

/**
 * Utility: Export layout for debugging/analysis
 */
export function exportLayout(result: LayoutResult): string {
  return JSON.stringify(result, null, 2);
}

/**
 * Utility: Compare two layouts for differences
 * Useful for regression detection in QA pipeline
 */
export function compareLayouts(layout1: LayoutResult, layout2: LayoutResult): {
  changed: boolean;
  nodeDifferences: number;
  averageDistance: number;
} {
  if (layout1.positions.length !== layout2.positions.length) {
    return {
      changed: true,
      nodeDifferences: Math.abs(
        layout1.positions.length - layout2.positions.length
      ),
      averageDistance: Infinity,
    };
  }

  let totalDistance = 0;
  let changedCount = 0;

  const posMap2 = new Map(layout2.positions.map((p) => [p.id, p]));

  for (const pos1 of layout1.positions) {
    const pos2 = posMap2.get(pos1.id);
    if (!pos2) {
      changedCount++;
      continue;
    }

    const distance = Math.sqrt(
      Math.pow(pos1.x - pos2.x, 2) + Math.pow(pos1.y - pos2.y, 2)
    );
    totalDistance += distance;

    // Consider "changed" if moved more than 20px
    if (distance > 20) {
      changedCount++;
    }
  }

  const averageDistance = totalDistance / layout1.positions.length;

  return {
    changed: changedCount > 0,
    nodeDifferences: changedCount,
    averageDistance,
  };
}
