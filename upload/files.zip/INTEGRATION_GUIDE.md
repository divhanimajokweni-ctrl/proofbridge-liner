# Epistemic DAG — QA Pipeline Integration Guide

## Overview

This document describes the integration of an **automated, multi-layer QA pipeline** into the Epistemic DAG project. The improvements are grounded from first principles—deconstructing inherited assumptions and building justified, testable layers.

---

## 1. Architecture Philosophy: Why 4 Layers?

### The Problem We're Solving

A complex system with:
- **Real-time data flow** (DAG merges, state repairs)
- **Complex visualizations** (d3-force graphs, federation meshes)
- **Cryptographic verification** (ZK proofs, MMR trees)
- **Policy enforcement** (invariant checking, repair logic)

...cannot be adequately tested by a single verification method. Each layer catches different classes of defects.

### Layer 1: Health Checks (API Availability)
**Thesis**: A system that cannot serve requests is fundamentally broken, regardless of code quality.

- **What it tests**: HTTP endpoint availability and basic response handling
- **Why it matters**: Detects deployment issues, service crashes, and database connectivity
- **How it works**: 
  - Makes HEAD requests to all API endpoints
  - Retries with exponential backoff (handles slow service startup)
  - Tracks response codes and latency
- **Failure modes caught**: 
  - Missing environment variables
  - Database initialization failures
  - Port conflicts or service crashes

### Layer 2: Browser Automation (Runtime Errors)
**Thesis**: A system that serves requests but crashes at runtime is worse than a crashed system—it silently fails.

- **What it tests**: Client-side JavaScript execution, hydration, React mounting
- **Why it matters**: Next.js/React systems can render HTML but fail when JavaScript initializes
- **How it works**:
  - Fetches the main page HTML
  - Parses for common error indicators (React errors, hydration failures)
  - Simulates section navigation by checking DOM markers
  - In production: Use Playwright/Puppeteer to actually run JavaScript in a browser
- **Failure modes caught**:
  - React hydration mismatches
  - Next.js data fetch failures
  - Global error handlers being invoked
  - Missing DOM elements (broken navigation)

### Layer 3: Visual Analysis (UX Defects)
**Thesis**: A system that "works" but renders incorrectly creates user confusion and erodes trust.

- **What it tests**: UI rendering correctness, layout stability, semantic color usage
- **Why it matters**: Visual bugs are often invisible to automated tests but obvious to users
  - Text truncation hiding critical information
  - Overlapping elements creating ambiguity
  - Color semantics (red for safe, green for error) inverting meaning
  - Responsive design breaking at certain viewport sizes
- **How it works**:
  - Captures screenshots via Playwright (simulated in current implementation)
  - Passes them to a Vision-Language Model (VLM) with structured prompts
  - Parses JSON responses for structured defect reporting
  - Compares against baseline images using pixel-level diffing
- **Failure modes caught**:
  - DAG graph overlaps from poor force simulation
  - Policy editor overflow on small screens
  - Badge labels truncated in federation view
  - Color-coded status indicators inverted

### Layer 4: Static Analysis (Code Quality)
**Thesis**: Code that passes runtime tests but violates patterns will eventually fail.

- **What it tests**: Type safety, linting rules, compiler warnings
- **Why it matters**: Catches issues that runtime tests miss:
  - Unused variables leading to dead code
  - Type mismatches in edge cases
  - React compiler optimizations not being applied
  - Accessibility violations (missing alt text, bad ARIA)
- **How it works**:
  - Runs `bun run lint` (ESLint configuration)
  - Parses output for errors and warnings
  - Treats warnings as failures (zero tolerance)
  - Integrates React Compiler rules
- **Failure modes caught**:
  - Type errors in props drilling
  - Unhandled promise rejections
  - Deprecated API usage
  - Missing accessibility labels

---

## 2. Quick Start

### Running the Full QA Pipeline

```bash
# Start the development server (in one terminal)
bun run dev

# In another terminal, run the full QA suite
bun qa

# Output: qa-report.json with detailed results
```

### Running Individual Layers

```bash
# Just health checks
bun qa:health

# Just browser automation
bun qa:browser

# Just visual analysis
bun qa:visual

# Just linting
bun qa:lint
```

### Interpreting the Report

The `qa-report.json` contains:

```json
{
  "timestamp": "2025-07-20T14:32:10.000Z",
  "environment": {
    "nodeVersion": "v22.0.0",
    "bunVersion": "1.0+",
    "platform": "linux"
  },
  "layers": {
    "health": {
      "passed": true,
      "failures": [],
      "duration": 2341
    },
    "browser": {
      "passed": true,
      "consoleErrors": [],
      "navigationIssues": [],
      "duration": 1502
    },
    "visual": {
      "passed": false,
      "issues": {
        "topology": ["DAG nodes overlapping on viewport < 1024px"]
      },
      "duration": 5203
    },
    "lint": {
      "passed": true,
      "errors": [],
      "duration": 892
    }
  },
  "summary": {
    "totalTests": 4,
    "passed": 3,
    "failed": 1,
    "overallPassed": false
  }
}
```

---

## 3. Integration into Workflow

### Pre-Commit Hook

Add to `.git/hooks/pre-commit`:

```bash
#!/bin/bash
set -e
echo "Running QA checks before commit..."
bun qa
if [ $? -ne 0 ]; then
    echo "❌ QA failed. Commit aborted."
    exit 1
fi
```

Make it executable:
```bash
chmod +x .git/hooks/pre-commit
```

### CI/CD (GitHub Actions)

Add `.github/workflows/qa.yml`:

```yaml
name: QA Pipeline

on:
  push:
    branches: [main, develop]
  pull_request:

jobs:
  qa:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: oven-sh/setup-bun@v1
      - run: bun install
      - run: bun run db:migrate
      - run: bun run build
      - run: bun run dev &
      - run: sleep 5  # Wait for server startup
      - run: bun qa
      - uses: actions/upload-artifact@v4
        if: always()
        with:
          name: qa-report
          path: qa-report.json
```

---

## 4. D3-Force Simulation Refinements

### Current Issue

The DAG topology graph uses d3-force to layout nodes dynamically. Problems:

1. **Jitter**: Nodes bounce and settle unpredictably during simulation
2. **Overlaps**: Multiple nodes occupy the same space
3. **Label collision**: Text labels obscure node relationships
4. **Non-deterministic**: Same data produces different layouts on different runs

### Solution: Convergence Before Render

**From first principles**: Simulation should settle before the user sees it.

#### Step 1: Pre-compute layout in a Web Worker

```typescript
// src/lib/dag-layout-worker.ts
export async function computeDAGLayout(
  nodes: DAGNode[],
  links: DAGLink[]
): Promise<LayoutResult> {
  return new Promise((resolve) => {
    const worker = new Worker(
      new URL('./dag-layout-worker-impl.js', import.meta.url),
      { type: 'module' }
    );

    worker.postMessage({ nodes, links });
    worker.onmessage = (e) => {
      resolve(e.data);
      worker.terminate();
    };
  });
}
```

#### Step 2: Converge with high alpha decay

```typescript
// src/lib/dag-layout-worker-impl.ts
const simulation = d3.forceSimulation(nodes)
  .force("link", d3.forceLink(links).id(d => d.id))
  .force("charge", d3.forceManyBody().strength(-200))
  .force("collide", d3.forceCollide().radius(d => d.radius + 20))
  .force("center", d3.forceCenter(width / 2, height / 2))
  .alphaDecay(0.05)  // Fast convergence
  .alphaTarget(0);   // Target: complete stop

// Run until fully converged
return new Promise(resolve => {
  simulation.on("end", () => {
    const positions = nodes.map(d => ({ id: d.id, x: d.x, y: d.y }));
    resolve(positions);
  });
});
```

#### Step 3: Use static layout + drag override

```typescript
// src/components/dag-topology.tsx
const [layout, setLayout] = useState<LayoutResult | null>(null);

useEffect(() => {
  computeDAGLayout(nodes, links).then(result => {
    setLayout(result);
  });
}, [nodes, links]);

if (!layout) return <LoadingSpinner />;

return (
  <DAGGraph
    nodes={nodes}
    links={links}
    staticLayout={layout}          // Use pre-computed positions
    allowDrag={true}               // User can adjust
    onDragEnd={handleDragEnd}      // Save overrides
  />
);
```

**Benefits**:
- ✅ Deterministic output (same input → same layout)
- ✅ No jitter or bouncing
- ✅ Label collision avoidance (collision radius includes text width)
- ✅ Responsive: pre-computation happens off-UI-thread
- ✅ Testable: layout can be compared pixel-by-pixel against baseline

---

## 5. VLM Prompt Engineering for Visual Defect Detection

### Current Approach: Naive VLM Prompts

Most VLM implementations fail because they ask open-ended questions:

```
"Analyze this screenshot for any visual problems"
```

This produces:
- Overly verbose responses
- Subjective interpretations
- Hallucinated issues that don't exist
- Inconsistent format (can't parse results)

### Solution: Structured, Domain-Specific Prompts

#### Principle 1: Always Require JSON Response

```typescript
const vlmPrompt = `
You are a UI/UX quality auditor for a distributed systems dashboard.

TASK: Analyze the provided screenshot and respond ONLY with valid JSON.

ANALYSIS CHECKLIST:
1. Text Overflow — Any text extending beyond container boundaries?
2. Element Overlap — Buttons, labels, or panels overlapping each other?
3. Color Semantics — Are status colors semantically correct?
   - Green = positive/safe
   - Red = error/critical
   - Yellow/Orange = warning
   - Gray = neutral/disabled
4. Alignment — Are elements properly aligned and spaced?
5. Contrast — Text readable against background (WCAG AA)?
6. Responsive — Layout adapt well to viewport size?

RESPONSE FORMAT (STRICT JSON):
{
  "status": "OK" | "DEFECTS_FOUND",
  "defects": [
    {
      "type": "text_overflow" | "overlap" | "color_semantic" | "alignment" | "contrast" | "responsive",
      "location": "describe where in the UI",
      "description": "specific issue observed",
      "severity": "critical" | "major" | "minor",
      "confidence": 0.0 to 1.0
    }
  ],
  "overallQuality": 0.0 to 1.0
}
`;
```

#### Principle 2: Section-Specific Prompts

Each dashboard section needs tailored checks:

```typescript
const SECTION_PROMPTS: Record<string, string> = {
  topology: `
    FOCUS: DAG graph visualization
    CHECK:
    1. Do nodes overlap (should be min 60px apart)?
    2. Are edge labels readable and not obscured?
    3. Does the force-directed layout look natural (no node clusters)?
    4. Are zoom/pan controls visible and properly positioned?
  `,

  federation: `
    FOCUS: Cross-organization reconciliation view
    CHECK:
    1. Are org labels truncated (especially long org names)?
    2. Is the gossip animation smooth (no jank)?
    3. Are trust indicators (colors) semantically correct?
    4. Is the organization tree hierarchically clear?
  `,

  studio: `
    FOCUS: Policy DSL editor and validation
    CHECK:
    1. Does the editor fit within viewport without horizontal scroll?
    2. Is syntax highlighting applied correctly?
    3. Are error messages visible and not cut off?
    4. Is the editor responsive on narrow screens?
  `,

  proofs: `
    FOCUS: ZK proof verification display
    CHECK:
    1. Are proof IDs fully visible (truncation)?
    2. Is the constraint graph readable at default zoom?
    3. Are verification status indicators clear?
    4. Do timestamps align properly in the proof history table?
  `,
};
```

#### Principle 3: Baseline Comparisons

Don't just check the current screenshot in isolation. Compare against known-good baselines:

```typescript
interface VisualBaseline {
  section: string;
  screenshot: Buffer;
  hash: string;          // SHA256 of image
  timestamp: string;
  metadata: {
    viewport: { width: number; height: number };
    theme: "light" | "dark";
    browser: string;
  };
}

async function compareAgainstBaseline(
  section: string,
  currentScreenshot: Buffer,
  baseline: VisualBaseline
): Promise<DiffResult> {
  // Pixel-level diff using pixelmatch
  const diff = pixelmatch(baseline.screenshot, currentScreenshot);
  
  if (diff.pixelsChanged < 100) {
    // Minor changes, skip VLM
    return { changed: false, reason: "within_tolerance" };
  }
  
  // Significant changes, invoke VLM for semantic analysis
  const vlmAnalysis = await analyzeWithVLM(currentScreenshot);
  return {
    changed: true,
    reason: "pixel_diff_exceeds_threshold",
    vlmAnalysis,
  };
}
```

#### Principle 4: Confidence Thresholds

Not all VLM outputs are equally trustworthy:

```typescript
interface AugmentedDefect {
  type: string;
  description: string;
  severity: string;
  confidence: number;
  actionable: boolean;  // Is this something we should block on?
}

function isActionable(defect: AugmentedDefect): boolean {
  // Only block CI for high-confidence critical issues
  if (defect.severity === "critical" && defect.confidence >= 0.85) {
    return true;
  }
  // Major issues at 0.9+ confidence
  if (defect.severity === "major" && defect.confidence >= 0.9) {
    return true;
  }
  // Minor issues at 0.95+ confidence (rare false positives)
  if (defect.severity === "minor" && defect.confidence >= 0.95) {
    return true;
  }
  return false;
}
```

---

## 6. Measurement & Continuous Improvement

### QA Report Metrics

The pipeline captures:

- **Layer success rate** (as % over time)
- **Defect distribution** (which layer catches most bugs?)
- **False positive rate** (VLM vs actual defects)
- **Coverage gaps** (sections not visited, endpoints not checked)
- **Regression trends** (is visual quality improving or degrading?)

### Dashboarding

Create a simple dashboard to track QA metrics:

```typescript
// src/app/admin/qa-metrics/page.tsx
export default async function QAMetricsPage() {
  const reports = await readQAReportsHistory(30); // Last 30 reports
  
  const stats = {
    averagePassRate: reports.filter(r => r.summary.overallPassed).length / reports.length,
    failuresByLayer: groupBy(reports, r => 
      Object.entries(r.layers)
        .filter(([_, v]) => !v.passed)
        .map(([k]) => k)
    ),
    slowestLayers: Object.entries(
      reports[reports.length - 1].layers
    ).sort(([, a], [, b]) => b.duration - a.duration),
  };

  return (
    <div>
      <h1>QA Metrics (Last 30 Days)</h1>
      <div>Pass Rate: {(stats.averagePassRate * 100).toFixed(1)}%</div>
      <div>Slowest Layer: {stats.slowestLayers[0][0]} ({stats.slowestLayers[0][1].duration}ms)</div>
    </div>
  );
}
```

### Feedback Loop

1. **Weekly review**: Look at `qa-report.json` from failed runs
2. **Root cause analysis**: Was it a real defect or a false positive?
3. **Adjust prompts**: If false positive, refine the VLM prompt
4. **Update baselines**: If truly a regression, accept it as new baseline
5. **Improve coverage**: If new defect type detected, add to next layer's checks

---

## 7. Production Deployment Checklist

- [ ] Environment variables set for all API endpoints
- [ ] Database migrations run before QA pipeline (`bun run db:migrate`)
- [ ] Services healthcheck endpoints responding in < 100ms
- [ ] VLM service credentials configured (if using external VLM)
- [ ] Screenshot directory (`qa-screenshots/`) writable
- [ ] QA report directory accessible for CI artifact upload
- [ ] Pre-commit hooks installed locally
- [ ] CI/CD workflow enabled and tested
- [ ] Baseline images captured for first run (bootstrap)
- [ ] Team notified of QA expectations

---

## 8. Troubleshooting

### "Health Check Failed: /api/policies returned 502"

**Cause**: Service not yet running or database not initialized.

**Fix**:
```bash
# In first terminal
bun run db:migrate
bun run dev

# Wait 5+ seconds for services to boot
# Then in second terminal
bun qa
```

### "Visual Analysis: Too many false positives from VLM"

**Cause**: VLM prompt is too open-ended.

**Fix**: Use section-specific prompts (see Section 5). Add confidence thresholds.

### "QA Passes locally but fails in CI"

**Cause**: Viewport size, font rendering, or timing differences between local and CI environment.

**Fix**:
```bash
# Capture baseline screenshots in CI-like environment
VIEWPORT_WIDTH=1280 VIEWPORT_HEIGHT=720 bun qa

# Store as baseline
cp qa-screenshots/* qa-baseline/
git add qa-baseline/
git commit -m "Update QA baselines for CI environment"
```

### "Browser Automation stuck on section 'topology'"

**Cause**: Section is taking too long to render (likely complex d3-force simulation).

**Fix**: Timeout threshold in browser check:

```typescript
const SECTION_TIMEOUT = 15000; // 15 seconds per section
await Promise.race([
  navigateToSection(section),
  new Promise((_, reject) => 
    setTimeout(() => reject(new Error(`Timeout: ${section}`)), SECTION_TIMEOUT)
  )
]);
```

---

## 9. Next Steps

1. **Implement full Playwright integration** for Layer 2 (currently simulated)
2. **Set up VLM service** for Layer 3 (currently simulated)
3. **Create dashboard** for QA metrics over time
4. **Train team** on QA report interpretation
5. **Establish SLA** (e.g., "QA pipeline must pass before merge")
6. **Automate baseline updates** on legitimate design changes

---

## Appendix: File Structure

```
epistemic-dag/
├── scripts/
│   └── qa-loop.ts              # Multi-layer QA pipeline (new)
├── src/
│   ├── app/
│   ├── components/
│   ├── lib/
│   │   ├── dag-layout-worker.ts        # (new) D3-force pre-computation
│   │   └── dag-layout-worker-impl.ts   # (new) Web Worker implementation
│   └── hooks/
├── qa-screenshots/             # Captured screenshots (created at runtime)
├── qa-baseline/                # Baseline screenshots for regression detection
├── qa-report.json              # Latest QA report (created at runtime)
├── package.json                # Updated with qa scripts (modified)
└── ...
```

---

## References

- **d3-force docs**: https://github.com/d3/d3-force
- **Playwright**: https://playwright.dev/
- **Vision-Language Models**: OpenAI GPT-4V, Claude 3 Vision, etc.
- **pixelmatch**: https://github.com/mapbox/pixelmatch
- **ESLint**: https://eslint.org/

---

*"Quality is not an attribute that happens to the system in the moment. Quality is built in, layer by layer, from first principles."*
